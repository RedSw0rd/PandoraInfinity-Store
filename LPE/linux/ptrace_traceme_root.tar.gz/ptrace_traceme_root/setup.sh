#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

LPEDirPath="/var/lib/pandora/usr/exploits/local"
dbPath="/var/lib/pandora/db/user/localxplz.db";

###########################################################################
#
#xid=$(date +%s | md5sum | awk '{ print $1 }')
#name="";
#desc="";
#cve="";
#cve2="";
#ref1="";
#ref2="";
#ref3="";
#system="";
#arch="";
#category="";
#usage="";
#versions="";
#compilation="";
#
###########################################################################

xid=$(date +%s | md5sum | awk '{ print $1 }')
name="ptrace_traceme_root";
desc="Linux 4.10 < 5.1.17 PTRACE_TRACEME local root";
cve1="CVE-2019-13272";
cve2="";
ref1="https://bugs.chromium.org/p/project-zero/issues/detail?id=1903";
ref2="-";
ref3="-";
system="LINUX";
arch="32";
category="KERNEL";
usage='
[user@localhost CVE-2019-13272]$ ./ptrace_traceme_root
Linux 4.10 < 5.1.17 PTRACE_TRACEME local root (CVE-2019-13272)
[.] Checking environment ...
[~] Done, looks good
[.] Searching policies for useful helpers ...
[.] Ignoring helper (does not exist): /usr/sbin/pk-device-rebind
[.] Trying helper: /usr/libexec/gsd-backlight-helper
[.] Spawning suid process (/usr/bin/pkexec) ...
[.] Tracing midpid ...
[~] Attached to midpid
[root@localhost CVE-2019-13272]# id
uid=0(root) gid=0(root) groups=0(root),1000(user)
';
versions="4.10 < 5.1.17";
compilation="gcc -Wall --std=gnu99 -s poc.c -o ptrace_traceme_root";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

dirname="ptrace_traceme_root"
targetFolder="$LPEDirPath/linux/kernel/$dirname"

if [[ -e "$targetFolder" ]]
then
	echo "|!| Folder $dirname already exists in $LPEDirPath/linux/kernel";
else
	mkdir "$targetFolder"
	mv src "$targetFolder"
	mv bin "$targetFolder"
	chown -R www-data: "$targetFolder"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO LOCAL_XPLOIT_DATABASE (XID, NAME, CVE, CVE2, REFERENCE, REFERENCE2, REFERENCE3, CATEGORIE, SYSTEM, ARCH, VERSION, DESC, COMPILE, USAGE) VALUES ('$xid', '$name', '$cve1', '$cve2', '$ref1', '$ref2', '$ref3', '$category', '$system', '$arch', '$version', '$desc', '$compilation', '$usage');"

	echo "|+| LPE $name was successfully installed"
	
fi

