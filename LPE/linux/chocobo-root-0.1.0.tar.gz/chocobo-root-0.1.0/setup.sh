#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

LPEDirPath="/var/lib/pandora/usr/exploits/local"
dbPath="/var/lib/pandora/db/user/localxplz.db";

###########################################################################
#
#xid=$(date +%s | md5sum | awk '{ print $1 }')
#name="";
#desc="";
#cve="";
#cve2="";
#ref1="";
#ref2="";
#ref3="";
#system="";
#arch="";
#category="";
#usage="";
#versions="";
#compilation="";
#
###########################################################################

xid=$(date +%s | md5sum | awk '{ print $1 }')
name="chocobo_root";
desc="Linux AF_PACKET race condition exploit";
cve1="CVE-2016-8655";
cve2="";
ref1="https://github.com/bcoles/kernel-exploits/tree/master/CVE-2016-8655";
ref2="-";
ref3="-";
system="LINUX";
arch="32";
category="KERNEL";
usage='user@ubuntu:~$ ./chocobo_root
linux AF_PACKET race condition exploit by rebel
kernel version: 4.4.0-51-generic #72
. . .
. . .
stage 2 completed
binary executed by kernel, launching rootshell
root@ubuntu:~# id
uid=0(root) gid=0(root) groups=0(root),1000(user)
';
versions="";
compilation="gcc chocobo_root.c -o chocobo_root -lpthread -Wall";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

dirname="chocobo_root"
targetFolder="$LPEDirPath/linux/kernel/$dirname"

if [[ -e "$targetFolder" ]]
then
	echo "|!| Folder $dirname already exists in $LPEDirPath/linux/kernel";
else
	mkdir "$targetFolder"
	mv src "$targetFolder"
	mv bin "$targetFolder"
	chown -R www-data: "$targetFolder"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO LOCAL_XPLOIT_DATABASE (XID, NAME, CVE, CVE2, REFERENCE, REFERENCE2, REFERENCE3, CATEGORIE, SYSTEM, ARCH, VERSION, DESC, COMPILE, USAGE) VALUES (\"$xid\", \"$name\", \"$cve1\", \"$cve2\", \"$ref1\", \"$ref2\", \"$ref3\", \"$category\", \"$system\", \"$arch\", \"$version\", \"$desc\", \"$compilation\", \"$usage\");"

	echo "|+| LPE $name was successfully installed"
fi

