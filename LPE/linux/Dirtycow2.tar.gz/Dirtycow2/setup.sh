#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

LPEDirPath="/var/lib/pandora/usr/exploits/local"
dbPath="/var/lib/pandora/db/user/localxplz.db";

###########################################################################
#
###########################################################################

xid=$(date +%s | md5sum | awk '{ print $1 }')
name="Dirtycow2";
desc="Linux Kernel 2.6.22 < 3.9 - \'Dirty COW\' \'PTRACE_POKEDATA\' Race Condition Privilege Escalation (/etc/passwd Method)";
cve1="CVE-2016-5195";
cve2="";
ref1="https://www.exploit-db.com/exploits/40839";
ref2="https://nvd.nist.gov/vuln/detail/CVE-2016-5195";
ref3="-";
system="LINUX";
arch="64";
category="KERNEL";
usage="./dirty";
versions="2.6.22 < 3.9";
compilation="gcc -pthread dirty.c -o dirty -lcrypt";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

dirname="Dirtycow2"
targetFolder="$LPEDirPath/linux/kernel/$dirname"

if [[ -e "$targetFolder" ]]
then
	echo "|!| Folder $dirname already exists in $LPEDirPath/linux/kernel";
else
	mkdir "$targetFolder"
	mv src "$targetFolder"
	mv bin "$targetFolder"
	chown -R www-data: "$targetFolder"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO LOCAL_XPLOIT_DATABASE (XID, NAME, CVE, CVE2, REFERENCE, REFERENCE2, REFERENCE3, CATEGORIE, SYSTEM, ARCH, VERSION, DESC, COMPILE, USAGE) VALUES ('$xid', '$name', '$cve1', '$cve2', '$ref1', '$ref2', '$ref3', '$category', '$system', '$arch', '$version', '$desc', '$compilation', '$usage');"

	echo "|+| LPE $name was successfully installed"
	
fi
