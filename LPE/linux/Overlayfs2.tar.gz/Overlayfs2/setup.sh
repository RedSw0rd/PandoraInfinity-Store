#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

LPEDirPath="/var/lib/pandora/usr/exploits/local"
dbPath="/var/lib/pandora/db/user/localxplz.db";

###########################################################################
#
#xid=$(date +%s | md5sum | awk '{ print $1 }')
#name="";
#desc="";
#cve="";
#cve2="";
#ref1="";
#ref2="";
#ref3="";
#system="";
#arch="";
#category="";
#usage="";
#versions="";
#compilation="";
#
###########################################################################

xid=$(date +%s | md5sum | awk '{ print $1 }')
name="Overlayfs2";
desc="Just another overlayfs exploit, works on kernels before 2015-12-26";
cve1="CVE-2015-8660";
cve2="";
ref1="https://www.exploit-db.com/exploits/39166";
ref2="-";
ref3="-";
system="LINUX";
arch="32";
category="KERNEL";
usage='
blah@ubuntu:~$ id
uid=1001(blah) gid=1001(blah) groups=1001(blah)
blah@ubuntu:~$ uname -a && cat /etc/issue
Linux ubuntu 3.19.0-42-generic #48~14.04.1-Ubuntu SMP Fri Dec 18 10:24:49 UTC 2015 x86_64 x86_64 x86_64 GNU/Linux
Ubuntu 14.04.3 LTS \n \l
blah@ubuntu:~$ ./overlayfail
root@ubuntu:~# id
uid=0(root) gid=1001(blah) groups=0(root),1001(blah)
';
versions="";
compilation="";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

dirname="Overlayfs2"
targetFolder="$LPEDirPath/linux/kernel/$dirname"

if [[ -e "$targetFolder" ]]
then
	echo "|!| Folder $dirname already exists in $LPEDirPath/linux/kernel";
else
	mkdir "$targetFolder"
	mv src "$targetFolder"
	mv bin "$targetFolder"
	chown -R www-data: "$targetFolder"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO LOCAL_XPLOIT_DATABASE (XID, NAME, CVE, CVE2, REFERENCE, REFERENCE2, REFERENCE3, CATEGORIE, SYSTEM, ARCH, VERSION, DESC, COMPILE, USAGE) VALUES ('$xid', '$name', '$cve1', '$cve2', '$ref1', '$ref2', '$ref3', '$category', '$system', '$arch', '$version', '$desc', '$compilation', '$usage');"

	echo "|+| LPE $name was successfully installed"
	
fi
