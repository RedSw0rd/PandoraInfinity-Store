#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

LPEDirPath="/var/lib/pandora/usr/exploits/local"
dbPath="/var/lib/pandora/db/user/localxplz.db";

###########################################################################
#
#xid=$(date +%s | md5sum | awk '{ print $1 }')
#name="";
#desc="";
#cve="";
#cve2="";
#ref1="";
#ref2="";
#ref3="";
#system="";
#arch="";
#category="";
#usage="";
#versions="";
#compilation="";
#
###########################################################################

xid=$(date +%s | md5sum | awk '{ print $1 }')
name="Overlayfs";
desc="Overlayfs incorrect permission handling - Ubuntu specific";
cve1="CVE-2015-1328";
cve2="";
ref1="https://www.exploit-db.com/exploits/37292";
ref2="http://people.canonical.com/~ubuntu-security/cve/2015/CVE-2015-1328.html";
ref3="-";
system="LINUX";
arch="32";
category="KERNEL";
usage='
user@ubuntu-server-1504:~$ id
uid=1000(user) gid=1000(user) groups=1000(user),24(cdrom),30(dip),46(plugdev)
user@ubuntu-server-1504:~$ ./ofs
spawning threads
mount #1
mount #2
child threads done
/etc/ld.so.preload created
creating shared library
# id
uid=0(root) gid=0(root) groups=0(root),24(cdrom),30(dip),46(plugdev),1000(user)
';
versions="3.13.0-24<3.13.0-55
3.16.0-25<3.16.0-41
3.19.0-18<3.19.0-21";
compilation="gcc ofs.c -o ofs";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

dirname="Overlayfs"
targetFolder="$LPEDirPath/linux/kernel/$dirname"

if [[ -e "$targetFolder" ]]
then
	echo "|!| Folder $dirname already exists in $LPEDirPath/linux/kernel";
else
	mkdir "$targetFolder"
	mv src "$targetFolder"
	mv bin "$targetFolder"
	chown -R www-data: "$targetFolder"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO LOCAL_XPLOIT_DATABASE (XID, NAME, CVE, CVE2, REFERENCE, REFERENCE2, REFERENCE3, CATEGORIE, SYSTEM, ARCH, VERSION, DESC, COMPILE, USAGE) VALUES ('$xid', '$name', '$cve1', '$cve2', '$ref1', '$ref2', '$ref3', '$category', '$system', '$arch', '$version', '$desc', '$compilation', '$usage');"

	echo "|+| LPE $name was successfully installed"
	
fi
