#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

LPEDirPath="/var/lib/pandora/usr/exploits/local"
dbPath="/var/lib/pandora/db/user/localxplz.db";

###########################################################################
#
#xid=$(date +%s | md5sum | awk '{ print $1 }')
#name="";
#desc="";
#cve="";
#cve2="";
#ref1="";
#ref2="";
#ref3="";
#system="";
#arch="";
#category="";
#usage="";
#versions="";
#compilation="";
#
###########################################################################

xid=$(date +%s | md5sum | awk '{ print $1 }')
name="PwnKit";
desc="Pkexec Local Privilege Escalation - Self-contained version";
cve1="CVE-2021-4034";
cve2="";
ref1="https://blog.qualys.com/vulnerabilities-threat-research/2022/01/25/pwnkit-local-privilege-escalation-vulnerability-discovered-in-polkits-pkexec-cve-2021-4034";
ref2="https://github.com/ly4k/PwnKit";
ref3="https://github.com/arthepsy/CVE-2021-4034/";
system="LINUX";
arch="ALL";
category="APPLI";
usage='
$ ./PwnKit
# id
# logout

If failed, remove temp files :
$ find / -name pkexec.so
';
versions="";
compilation="gcc -shared PwnKit.c -o PwnKit -Wl,-e,entry -fPIC";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

dirname="PwnKit"
targetFolder="$LPEDirPath/linux/appli/$dirname"

if [[ -e "$targetFolder" ]]
then
	echo "|!| Folder $dirname already exists in $LPEDirPath/linux/kernel";
else
	mkdir "$targetFolder"
	mv src "$targetFolder"
	mv bin "$targetFolder"
	chown -R www-data: "$targetFolder"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO LOCAL_XPLOIT_DATABASE (XID, NAME, CVE, CVE2, REFERENCE, REFERENCE2, REFERENCE3, CATEGORIE, SYSTEM, ARCH, VERSION, DESC, COMPILE, USAGE) VALUES ('$xid', '$name', '$cve1', '$cve2', '$ref1', '$ref2', '$ref3', '$category', '$system', '$arch', '$version', '$desc', '$compilation', '$usage');"

	echo "|+| LPE $name was successfully installed"
	
fi
