#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/usr/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"
	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# PrintSpoofer32.exe
###########################################################################

targetFile="content/PrintSpoofer32.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Local Privilege Escalation tool"
		help="AUTHOR:Clément Labro
URL:https://github.com/itm4n/PrintSpoofer

From LOCAL/NETWORK SERVICE to SYSTEM by abusing SeImpersonatePrivilege on Windows 10 and Server 2016/2019.

For more information: https://itm4n.github.io/printspoofer-abusing-impersonate-privileges/.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi


###########################################################################
# PrintSpoofer64.exe
###########################################################################

targetFile="content/PrintSpoofer64.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PRIVESC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Local Privilege Escalation tool"
		help="AUTHOR:Clément Labro
URL:https://github.com/itm4n/PrintSpoofer

From LOCAL/NETWORK SERVICE to SYSTEM by abusing SeImpersonatePrivilege on Windows 10 and Server 2016/2019.

For more information: https://itm4n.github.io/printspoofer-abusing-impersonate-privileges/.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

