#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/usr/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"
	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# Rubeus-dotnet-v3.5.exe
###########################################################################

targetFile="content/Rubeus-dotnet-v3.5.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="DOMAIN"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Toolset for raw Kerberos interaction and abuses"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Rubeus

Rubeus is a C# toolset for raw Kerberos interaction and abuses.
It is heavily adapted from Benjamin Delpy\'s Kekeo project (CC BY-NC-SA 4.0 license) and Vincent LE TOUX\'s MakeMeEnterpriseAdmin project (GPL v3.0 license).
Full credit goes to Benjamin and Vincent for working out the hard components of weaponization- without their prior work this project would not exist.

Binary release from https://github.com/r3motecontrol/Ghostpack-CompiledBinaries.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# Rubeus-dotnet-v4.5.exe
###########################################################################

targetFile="content/Rubeus-dotnet-v4.5.exe";


if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="DOMAIN"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Toolset for raw Kerberos interaction and abuses"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Rubeus

Rubeus is a C# toolset for raw Kerberos interaction and abuses.
It is heavily adapted from Benjamin Delpy\'s Kekeo project (CC BY-NC-SA 4.0 license) and Vincent LE TOUX\'s MakeMeEnterpriseAdmin project (GPL v3.0 license).
Full credit goes to Benjamin and Vincent for working out the hard components of weaponization- without their prior work this project would not exist.

Binary release from https://github.com/r3motecontrol/Ghostpack-CompiledBinaries.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# Rubeus-dotnet-v4.7.2.exe
###########################################################################

targetFile="content/Rubeus-dotnet-v4.7.2.exe";


if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="DOMAIN"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Toolset for raw Kerberos interaction and abuses"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Rubeus

Rubeus is a C# toolset for raw Kerberos interaction and abuses.
It is heavily adapted from Benjamin Delpy\'s Kekeo project (CC BY-NC-SA 4.0 license) and Vincent LE TOUX\'s MakeMeEnterpriseAdmin project (GPL v3.0 license).
Full credit goes to Benjamin and Vincent for working out the hard components of weaponization- without their prior work this project would not exist.

Binary release from https://github.com/r3motecontrol/Ghostpack-CompiledBinaries.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

