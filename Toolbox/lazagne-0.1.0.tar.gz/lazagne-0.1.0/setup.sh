#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/usr/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"

	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# LAZAGNE.EXE
###########################################################################

targetFile="content/LaZagne.exe";


if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="SIPHON"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Open Source Local Password Recovery Tool"
		help="AUTHOR:AlessandroZ
URL:https://github.com/AlessandroZ/LaZagne

The LaZagne project is an open source application used to retrieve lots of passwords stored on a local computer.
Each software stores its passwords using different techniques (plaintext, APIs, custom algorithms, databases, etc.).
This tool has been developed for the purpose of finding these passwords for the most commonly-used software.

Usage :

- Launch all modules

laZagne.exe all


- Launch only a specific module

laZagne.exe browsers


- Launch only a specific software script

laZagne.exe browsers -firefox


- Write all passwords found into a file (-oN for Normal txt, -oJ for Json, -oA for All).

laZagne.exe all -oN
laZagne.exe all -oA -output C:\Users\test\Desktop


- Get help

laZagne.exe -h
laZagne.exe browsers -h


- Change verbosity mode (2 different levels)

laZagne.exe all -vv


- Quiet mode (nothing will be printed on the standard output)

laZagne.exe all -quiet -oA


- To decrypt domain credentials, it could be done specifying the user windows password. Otherwise it will try all passwords already found as windows passwords.

laZagne.exe all -password ZapataVive


Binary Release.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# LAZAGNE v2.4.6.tar.gz
###########################################################################

targetFile="content/v2.4.6.tar.gz";


if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="SIPHON"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Open Source Local Password Recovery Tool"
		help="AUTHOR:AlessandroZ
URL:https://github.com/AlessandroZ/LaZagne

The LaZagne project is an open source application used to retrieve lots of passwords stored on a local computer.
Each software stores its passwords using different techniques (plaintext, APIs, custom algorithms, databases, etc.).
This tool has been developed for the purpose of finding these passwords for the most commonly-used software.
"

		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

