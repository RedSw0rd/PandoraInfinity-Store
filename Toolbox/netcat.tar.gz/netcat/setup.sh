#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/usr/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"
	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# nc.exe
###########################################################################

targetFile="content/nc.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="MISC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="TCP/IP Swiss Army Knife"
		help="AUTHOR:*hobbit* & Weld Pond
URL:https://github.com/int0x33/nc.exe/

Netcat for NT is the tcp/ip \"Swiss Army knife\" that never made it into any of the resource kits.
It has proved to be an extremely versatile tool on the unix platform.
So why should NT always be unix's poor cousin when it comes to tcp/ip testing and exploration ?
I bet many NT admins out there keep a unix box around to use tools such as Netcat or to test their systems
with the unix version of an NT vulnerability exploit. With Netcat for NT part of that feeling disempowerment is over.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# nc64.exe
###########################################################################

targetFile="content/nc64.exe";


if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="MISC"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="TCP/IP Swiss Army Knife"
		help="AUTHOR:*hobbit* & Weld Pond
URL:https://github.com/int0x33/nc.exe/

Netcat for NT is the tcp/ip \"Swiss Army knife\" that never made it into any of the resource kits.
It has proved to be an extremely versatile tool on the unix platform.
So why should NT always be unix's poor cousin when it comes to tcp/ip testing and exploration ?
I bet many NT admins out there keep a unix box around to use tools such as Netcat or to test their systems
with the unix version of an NT vulnerability exploit. With Netcat for NT part of that feeling disempowerment is over.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"

			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		else
			categoryID=$(sqlite3 "$dbPath" "SELECT ID FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$categoryID', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

