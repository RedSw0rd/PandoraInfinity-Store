#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/usr/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"
	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
#
###########################################################################

targetFile="content/Seatbelt-NetFramework_4.0_x64.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="SIPHON"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Local Gathering-info tool"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Seatbelt

Seatbelt is a C# project that performs a number of security oriented host-survey \"safety checks\" relevant from both offensive and defensive security perspectives.

@andrewchiles\'s HostEnum.ps1 script and @tifkin_\'s Get-HostProfile.ps1 provided inspiration for many of the artifacts to collect.

@harmj0y and @tifkin_ are the primary authors of this implementation.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/Seatbelt-NetFramework_4.0_x86.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="SIPHON"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Local Gathering-info tool"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Seatbelt

Seatbelt is a C# project that performs a number of security oriented host-survey \"safety checks\" relevant from both offensive and defensive security perspectives.

@andrewchiles\'s HostEnum.ps1 script and @tifkin_\'s Get-HostProfile.ps1 provided inspiration for many of the artifacts to collect.

@harmj0y and @tifkin_ are the primary authors of this implementation.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/Seatbelt-NetFramework_4.7_x64.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="SIPHON"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Local Gathering-info tool"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Seatbelt

Seatbelt is a C# project that performs a number of security oriented host-survey \"safety checks\" relevant from both offensive and defensive security perspectives.

@andrewchiles\'s HostEnum.ps1 script and @tifkin_\'s Get-HostProfile.ps1 provided inspiration for many of the artifacts to collect.

@harmj0y and @tifkin_ are the primary authors of this implementation.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
#
###########################################################################

targetFile="content/Seatbelt-NetFramework_4.7_x86.exe";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="SIPHON"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="WINDOWS"
		desc="Local Gathering-info tool"
		help="AUTHOR:GhostPack
URL:https://github.com/GhostPack/Seatbelt

Seatbelt is a C# project that performs a number of security oriented host-survey \"safety checks\" relevant from both offensive and defensive security perspectives.

@andrewchiles\'s HostEnum.ps1 script and @tifkin_\'s Get-HostProfile.ps1 provided inspiration for many of the artifacts to collect.

@harmj0y and @tifkin_ are the primary authors of this implementation.
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi
