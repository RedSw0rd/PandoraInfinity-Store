#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

EvilStorePath="/var/lib/pandora/usr/evilstore/stock"
dbPath="/var/lib/pandora/db/user/evilstore.db";

###########################################################################
# FUNCTIONS
###########################################################################

copy_file_with_suffix() {

	src_file="$1"
	dest_dir="$2"
	base_name=$(basename "$src_file")
	dest_file="$dest_dir/$base_name"

	if [ -e "$dest_file" ]; then

		suffix=1

		while [ -e "${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}" ]; do
			((suffix++))
		done

		dest_file="${dest_dir}/${base_name%.*}(${suffix}).${base_name##*.}"
	fi

	cp "$src_file" "$dest_file"
	echo "$dest_file"
}

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# nmap-7.94SVN-aarch64-portable.tar.gz
###########################################################################

targetFile="content/nmap-7.94SVN-aarch64-portable.tar.gz";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PACKAGES"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Network discovery and security auditing tool"
		help="AUTHOR:fyodor
URL:https://nmap.org/

Nmap (Network Mapper) is a free and open source utility for network discovery and security auditing.
Many systems and network administrators also find it useful for tasks such as network inventory, managing service upgrade schedules,
and monitoring host or service uptime. Nmap uses raw IP packets in novel ways to determine what hosts are available on the network,
what services (application name and version) those hosts are offering, what operating systems (and OS versions) they are running,
what type of packet filters/firewalls are in use, and dozens of other characteristics.
It was designed to rapidly scan large networks, but works fine against single hosts.

Portable release from https://github.com/ernw/static-toolbox/releases
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# nmap-7.94SVN-armhf-portable.tar.gz
###########################################################################

targetFile="content/nmap-7.94SVN-armhf-portable.tar.gz";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PACKAGES"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Network discovery and security auditing tool"
		help="AUTHOR:fyodor
URL:https://nmap.org/

Nmap (Network Mapper) is a free and open source utility for network discovery and security auditing.
Many systems and network administrators also find it useful for tasks such as network inventory, managing service upgrade schedules,
and monitoring host or service uptime. Nmap uses raw IP packets in novel ways to determine what hosts are available on the network,
what services (application name and version) those hosts are offering, what operating systems (and OS versions) they are running,
what type of packet filters/firewalls are in use, and dozens of other characteristics.
It was designed to rapidly scan large networks, but works fine against single hosts.

Portable release from https://github.com/ernw/static-toolbox/releases
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# nmap-7.94SVN-x86_64-portable.tar.gz
###########################################################################

targetFile="content/nmap-7.94SVN-x86_64-portable.tar.gz";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PACKAGES"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Network discovery and security auditing tool"
		help="AUTHOR:fyodor
URL:https://nmap.org/

Nmap (Network Mapper) is a free and open source utility for network discovery and security auditing.
Many systems and network administrators also find it useful for tasks such as network inventory, managing service upgrade schedules,
and monitoring host or service uptime. Nmap uses raw IP packets in novel ways to determine what hosts are available on the network,
what services (application name and version) those hosts are offering, what operating systems (and OS versions) they are running,
what type of packet filters/firewalls are in use, and dozens of other characteristics.
It was designed to rapidly scan large networks, but works fine against single hosts.

Portable release from https://github.com/ernw/static-toolbox/releases
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi

###########################################################################
# nmap-7.94SVN-x86-portable.tar.gz
###########################################################################

targetFile="content/nmap-7.94SVN-x86-portable.tar.gz";

if [[ -e "$targetFile" ]]
then
	# CHECK IF FILE ALREADY EXISTS
	hash=$(md5sum "$targetFile" | awk '{ print $1 }')
	hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE WHERE HASH = '$hash';")
	if [ "$hash_exists" -eq 0 ]
	then
		####################################################################################
		category="PACKAGES"
		categorylower=$(echo "$category" | tr '[:upper:]' '[:lower:]')

		os="LINUX"
		desc="Network discovery and security auditing tool"
		help="AUTHOR:fyodor
URL:https://nmap.org/

Nmap (Network Mapper) is a free and open source utility for network discovery and security auditing.
Many systems and network administrators also find it useful for tasks such as network inventory, managing service upgrade schedules,
and monitoring host or service uptime. Nmap uses raw IP packets in novel ways to determine what hosts are available on the network,
what services (application name and version) those hosts are offering, what operating systems (and OS versions) they are running,
what type of packet filters/firewalls are in use, and dozens of other characteristics.
It was designed to rapidly scan large networks, but works fine against single hosts.

Portable release from https://github.com/ernw/static-toolbox/releases
"
		#####################################################################################
		encoded_help=$(echo -n "$help" | base64)
		date=$(date +%s)

		# CHECK IF CATEGORY ALREADY EXISTS
		category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EVILFILE_CATEGORY WHERE NAME = '$category';")
		if [ "$category_exists" -eq 0 ]
		then
			# CREATE NEW CATEGORY
			sqlite3 "$dbPath" "INSERT INTO EVILFILE_CATEGORY (NAME) VALUES ('$category');"
			mkdir "$EvilStorePath/$categorylower"
			chown www-data: "$EvilStorePath/$categorylower"
		fi

		# COPY FILE
		filename=$(copy_file_with_suffix "$targetFile" "$EvilStorePath/$categorylower")
		filesize=$(stat -c%s "$filename")

		if [[ -e "$filename" ]]
		then
			sqlite3 "$dbPath" "INSERT INTO EVILFILE (TYPE, OS, PATH, DESC, HELP, HASH, SIZE, DATE) VALUES ('$category', '$os', '$filename', '$desc', '$encoded_help', '$hash', '$filesize', $date);"
			echo "|+| File $filename was successfully installed"
		fi
	else
		echo "|!| File is already present in EvilStore"
	fi
fi
