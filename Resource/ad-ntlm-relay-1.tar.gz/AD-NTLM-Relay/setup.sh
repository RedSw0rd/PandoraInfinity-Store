#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

documentDirPath="/var/www/pandora/usr/res/note"
dbPath="/var/lib/pandora/db/resource/ttnote.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

name="AD NTLM Relay"
filename="ADNTLMRelay.php"
category="ACTIVE DIRECTORY"
desc="Active Directory Pentest Part 4 - NTLM Relay"

if [[ -e "content/$filename" ]]
then
        hash=$(md5sum "content/$filename" | awk '{ print $1 }')
        hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM TT_NOTES WHERE HASH = '$hash';")
        if [ "$hash_exists" -ne 0 ]
	then
		echo "|!| File $filename already exists in $documentDirPath";
	else
		mv "content/$filename" "$documentDirPath/$filename"

		if [[ -e "$documentDirPath/$filename" ]]
		then
                        category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM TT_NOTES_CATEGORY WHERE NAME = '$category';")
                        if [ "$category_exists" -eq 0 ]
                        then
                                # CREATE NEW CATEGORY
                                sqlite3 "$dbPath" "INSERT INTO TT_NOTES_CATEGORY (NAME) VALUES ('$category');"
                        fi

			filesize=$(stat -c%s "$documentDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO TT_NOTES (NAME, DESC, CATEGORY, SIZE, PATH, HASH, DATE) VALUES ('$name', '$desc', '$category', '$filesize', '/usr/res/note/$filename', '$hash', '$date');"
                        echo "|+| Tactical/Technique note $filename was successfully installed"
		fi
	fi
fi
