<table class="tt-header">
<tr>
<td class="categorie">Category:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Date:</td>
<td class="date-text">23/06/2018</td>
</tr>
</table>
<div class="tt-header-title">Fundamentals</div>
<table class="tt-header">
<tr>
<td class="categorie">Author:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Lang</td>
<td class="date-text">FR</td>
</tr>
</table>

<div class="sommaire">
</div>

<h2 class="title">Introduction</h2>
<p>
Once a foothold is gained in the network under audit, the first step will be to performs a recon/scanning phase.<br/>
While this step, the pentester need to identify exaustivly all Windows system into the same network and their systems versions.
</p>

<h3 class="subtitle">Pre-requis</h2>
<p>
Access into the local network.
</p>

<h3 class="subtitle">Context</h2>
<p>
Thise stage don't need any credentials.
</p>


<h2 class="title">Introduction</h2>
<p>
Once a foothold is gained in the network under audit, the pentester’s primary objective to compromise the domain is to obtain a valid login/password pair, ideally with administrative privileges.<br/><br/>
With these credentials, the pentester will have the ability to perform a deeper enumeration step to retrieve all the information needed to become the domain administrator.
</p>


<h2 class="title">Pre-requis</h2>
<p>
To complete this step, we need all informations obtained previously such as :
- All windows hosts
- All
</p>

<br/>

<p>
Unfortenly, informations about Windows techn is not enought.
Previously, you have certainly scanned each hosts and discovered also all web servers.
By browsing all internal web service, we can find many others resources such document or emails and more.
</p>

<p>
So, this step consider you have already mapped the whole network.
</p>



<h2 class="title">User list build</h2>








<h2 class="title">Anonymous connexion</h2>
<p>
In the past, null sessions or anonymous connections allowed obtaining a lot of information without needing any passwords.<br/>
However, in modern environments, null sessions are less common but may still be present.<br/>
Therefore, before starting the credential hunt, you can try using null session / anonymous connections on certain services to gather useful information.
</p>
<br/>
<p>
To test if a Windows system accept null session :
</p>
<pre class="cmdoutput-win">
# smbclient -N -L \\TARGET_IP
</pre>

<p>
If shares are displayed, the system accept null session.<br/>
However, you will obtain the error message NT_STATUS_ACCESS_DENIED.
</p>

<h3 class="subtitle">rpcclient</h2>
<p>
RPC service can permit anonymous connexion
</p>


<h3 class="subtitle">ldapsearch</h2>
<p>
LDAP service can allow anonymous connections.<br/>
With the ldapsearch tool, we can use the -x flag to perform an anonymous connection.<br/>
Below is a list of commands to interact anonymously with the LDAP service running on the Domain Controller.
</p>

<p>
View the naming contexts :
</p>
<pre class="cmdoutput-win">
# ldapsearch -x -H ldap://IP -s base namingcontexts
</pre>

<p>
Dump all users :
</p>
<pre class="cmdoutput-win">
# ldapsearch -x -b "dc=htb,dc=local" -h TARGET_IP -p 389 '(ObjectClass=User)' sAMAccountName | grep sAMAccountName | awk '{print $2}'
</pre>

<p>
Dump all service accounts :
</p>
<pre class="cmdoutput-win">
# ldapsearch -x -b "dc=htb,dc=local" -h TARGET_IP -p 389 | grep -i -a 'Service Accounts'
</pre>







<h2 class="title">Kerberos</h2>

<p>
To enumerate usernames, the tool (https://github.com/ropnop/kerbrute) Kerbrute sends TGT requests with no pre-authentication.<br/><br/>
if the KDC responds with a PRINCIPAL UNKNOWN error, the username does not exist.<br/>However, if the KDC prompts for pre-authentication, we know the username exists and we move on.<br/><br/>
This does not cause any login failures so it will not lock out any accounts. This generates a Windows event ID 4768 if Kerberos logging is enabled.<br/>
</p>
<pre class="cmdoutput-win">
# root@kali:~# ./kerbrute_linux_amd64 userenum -d lab.ropnop.com usernames.txt
</pre>











<h2 class="title">Sources:</h2>


<ul>
<li>
https://github.com/nirajkharel/AD-Pentesting-Notes</li>

</ul>
