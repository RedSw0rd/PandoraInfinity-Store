<script>
function copyToClipboard(element) {
        navigator.clipboard.writeText(element.textContent);
}
</script>
<table class="tt-header">
<tr>
<td class="categorie">Category:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Date:</td>
<td class="date-text">23/06/2018</td>
</tr>
</table>
<div class="tt-header-title">The fundamentals</div>
<table class="tt-header">
<tr>
<td class="categorie">Author:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Lang</td>
<td class="date-text">FR</td>
</tr>
</table>

<div class="summary">
<span class='t'>1 - <a href="#1">Introduction</a></span>
<span class='st'>1.1 - <a href="#1.1">Pre-requis</a></span>
<span class='st'>1.2 - <a href="#1.2">Context</a></span>
</div>

<br/>
<a id="1"></a>
<h2 class="title">Introduction</h2>
<p>
</p>

<a id="1.1"></a>
<h3 class="subtitle">Pre-requis</h3>
<p>
Access into the local network.
</p>

<a id="1.2"></a>
<h3 class="subtitle">Context</h3>
<p>
Thise stage don't need any credentials.
</p>


<br/>
<h2 class="title">Domain</h2>
<p>
</pa>


<br/>
<h2 class="title">Active Directory</h2>
<p>
</pa>


<br/>
<h2 class="title">Domain controler</h2>
<p>
</pa>


<br/>
<h2 class="title">Kerberos</h2>
<p>
</pa>


<br/>
<h2 class="title">Protocols</h2>
<p>
</pa>

<h3 class="subtitle">NBT-NS</h2>
<p>
Thise stage don't need any credentials.
</p>


<h3 class="subtitle">LLMNR</h2>
<p>
This stage don't need any credentials.
</p>


<br/>
<h2 class="title">Conclusion</h2>
<p>
</p>

<br/>
<h2 class="title">Sources:</h2>
<ul>
<li>- <a href='https://juggernaut-sec.com/ntlm-relay-attacks/' target='_blank'>https://juggernaut-sec.com/ntlm-relay-attacks/</a></li>
<li>- <a href='https://www.sevenlayers.com/index.php/219-domain-takeover' target='_blank'>https://www.sevenlayers.com/index.php/219-domain-takeover</a></li>
</ul>

<br/>
<br/>

