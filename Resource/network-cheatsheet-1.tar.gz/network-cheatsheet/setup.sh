#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

imageDirPath="/var/www/pandora/usr/res/image"
dbPath="/var/lib/pandora/db/resource/image.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

name="ICMP Status code"
filename="ICMP-status-code.png"
newFilename=$(date +%s | sha256sum | awk '{ print $1 }')_$filename
desc="ICMP Status Code Cheat Sheet"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$imageDirPath/$newFilename" ]]
	then
		echo "|!| File $filename already exists in $imageDirPath";
	else
		mv "content/$filename" "$imageDirPath/$newFilename"

		if [[ -e "$imageDirPath/$newFilename" ]]
		then
			#
			filesize=$(stat -c%s "$imageDirPath/$newFilename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO IMAGE (NAME, DESC, SIZE, PATH, DATE) VALUES ('$name', '$desc', '$filesize', '/usr/res/image/$newFilename', '$date');"

			echo "|+| Image $filename was successfully installed"
		fi
	fi
fi


