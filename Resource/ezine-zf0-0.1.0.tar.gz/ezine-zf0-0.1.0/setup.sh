#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

ezineDirPath="/var/lib/pandora/usr/resources/ezine"
dbPath="/var/lib/pandora/db/resource/ezine.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# EZINE NAME
###########################################################################

ezinename="ZF0"
ezinedesc="Zero For Owned"

if [[ ! -e "$ezineDirPath/$ezinename" ]]
then
	#
	mkdir "$ezineDirPath/$ezinename"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO EZINE_NAME (NAME, DESC) VALUES ('$ezinename', '$ezinedesc')"
fi

###########################################################################
# EZINE FILE
###########################################################################

filename="zf0.txt"
issue="1"
filenum="1"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="zf0-2.txt"
issue="2"
filenum="1"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="zf0-3.txt"
issue="3"
filenum="1"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="zf0-4.txt"
issue="4"
filenum="1"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="zf0-5.txt"
issue="5"
filenum="1"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi



