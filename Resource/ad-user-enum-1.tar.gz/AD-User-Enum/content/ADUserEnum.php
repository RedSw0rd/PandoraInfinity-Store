<script>
function copyToClipboard(element) {
        navigator.clipboard.writeText(element.textContent);
}
</script>
<table class="tt-header">
<tr>
<td class="categorie">Category:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Date:</td>
<td class="date-text">23/06/2018</td>
</tr>
</table>
<div class="tt-header-title">User Enumeration</div>
<table class="tt-header">
<tr>
<td class="categorie">Author:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Lang</td>
<td class="date-text">FR</td>
</tr>
</table>

<div class="summary">
<span class='t'>1 - <a href="#1">Introduction</a></span>
<span class='st'>1.1 - <a href="#1.1">Pre-requis</a></span>
<span class='st'>1.2 - <a href="#1.2">Context</a></span>
</div>

<br/>
<a id="1"></a>
<h2 class="title">Introduction</h2>
<p>
Once a foothold is gained in the network under audit, the pentester’s primary objective to compromise the domain is to obtain a valid login/password pair, ideally with administrative privileges.<br/><br/>
With these credentials, the pentester will have the ability to perform a deeper enumeration step to retrieve all the information needed to become the domain administrator.
</p>

<a id="1.1"></a>
<h3 class="subtitle">Pre-requis</h3>
<p>
To complete this step, we need all informations obtained previously such as :
- All windows hosts
- All
</p>
<p>
Unfortenly, informations about Windows techn is not enought.
Previously, you have certainly scanned each hosts and discovered also all web servers.
By browsing all internal web service, we can find many others resources such document or emails and more.
</p>
<p>
So, this step consider you have already mapped the whole network.
</p>

<a id="1.1"></a>
<h3 class="subtitle">Context</h3>
<p>
Thise stage don't need any credentials.
</p>

<br/>
<h2 class="title">Anonymous connexion</h2>
<p>
In the past, null sessions or anonymous connections allowed obtaining a lot of information without needing any passwords.<br/>
However, in modern environments, null sessions are less common but may still be present.<br/>
Therefore, before starting the credential hunt, you can try using null session / anonymous connections on certain services to gather useful information.
</p>
<br/>
<p>
To test if a Windows system accept null session :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>smbclient -N -L \\TARGET_IP</span>
</pre>

<p>
If shares are displayed, the system accept null session.<br/>
However, you will obtain the error message NT_STATUS_ACCESS_DENIED.
</p>


<h3 class="subtitle">enum4linux</h3>
<p>
If a windows host accept null session, we can use enum4linux to dump the system's user with the -U flag :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>enum4linux -U TARGET_IP</span>
</pre>


<h3 class="subtitle">RID Cycling</h3>
<p>
If a windows host accept null session, we can use XXX to find more accounts.
enum4linux can also be used to exploit this technique.
</p>

<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'># enum4linux </span>
</pre>


<h3 class="subtitle">smbmap</h3>
<p>
If a windows host accept null session,
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>smbmap</span>
</pre>


<h3 class="subtitle">rpcclient</h3>
<p>
RPC service can permit anonymous connexion
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>smbmap</span>
</pre>



<h3 class="subtitle">ldapsearch</h3>
<p>
LDAP service can allow anonymous connections.<br/>
With the ldapsearch tool, we can use the -x flag to perform an anonymous connection.<br/>
Below is a list of commands to interact anonymously with the LDAP service running on the Domain Controller.
</p>

<p>
View the naming contexts :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>ldapsearch -x -H ldap://IP -s base namingcontexts</span>
</pre>

<p>
Dump all users :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>ldapsearch -x -b "dc=htb,dc=local" -h TARGET_IP -p 389 '(ObjectClass=User)' sAMAccountName | grep sAMAccountName | awk '{print $2}'</span>
</pre>

<p>
Dump all service accounts :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>ldapsearch -x -b "dc=htb,dc=local" -h TARGET_IP -p 389 | grep -i -a 'Service Accounts'</span>
</pre>


<h3 class="subtitle">FTP</h3>
<p>
Some FTP configuration permit anonymous connection.
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>command</span>
</pre>

<div class='notice'><div>
At the end of this step, we will have identified all services that accept anonymous connection and dumped all avaibles informations about accouns/usernames.
</div></div>


<br/>
<h2 class="title">Internet/Intranet</h2>
<p>
While our initial recon phase, you have probaly identified some web servers. By browsing theses websites, you can find some username/lastname or email adresses into
the contact section, team members, etc.
</p>


<h3 class="subtitle">Web Server</h3>
<p>
While our initial recon phase, you have probaly identified some web servers. By browsing theses websites, you can find some username/lastname or email adresses into
the contact section, team members, etc.
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>wpscan -e users</span>
</pre>


<h3 class="subtitle">Meta data</h3>
<p>
Somes documents can insert the author and others informations into the metadata of the documents.
These documents have normaly been discovered into shared folder, ftp server or web servers.
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>wget http://192.168.1.10/doc.docs | exif </span>
</pre>


<h3 class="subtitle">Public resources</h3>
<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>command</span>
</pre>


<div class='notice'><div>
At the end of this step, we have compiled a account list.
</div></div>



<br/>
<h2 class="title">Common Username/Family name</h2>
<p>
If despite our search we haven't found any account or to complete our actual list, we can geneate a list based on the most common username.
</p>


<h3 class="subtitle">Generate a list</h3>
<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>command</span>
</pre>


<h3 class="subtitle">Account format</h3>
<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>command</span>
</pre>

<div class='notice'><div>
At the end of this step, we have compiled a account list.
</div></div>

<div class='important'><div>
At this stage, we dont known if all account / usernames collected exists on target systems.<br/>
Before trying to brute force an account, we need to be sure than this account is enabled.
</div></div>


<br/>
<h2 class="title">Account Validation</h2>
<p>
</p>

<h3 class="subtitle">Kerberos</h3>
<p>
To enumerate usernames, the tool (https://github.com/ropnop/kerbrute) Kerbrute sends TGT requests with no pre-authentication.<br/><br/>
if the KDC responds with a PRINCIPAL UNKNOWN error, the username does not exist.<br/>However, if the KDC prompts for pre-authentication, we know the username exists and we move on.<br/><br/>
This does not cause any login failures so it will not lock out any accounts. This generates a Windows event ID 4768 if Kerberos logging is enabled.<br/>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'># ./kerbrute_linux_amd64 userenum -d lab.ropnop.com usernames.txt</span>
</pre>


<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'># nmap -p88 --script=krb5-enum-users --script-args="krb5-enum-users.realm='domain', userdb=user_list_file" DC_IP</span>
</pre>

<div class='theory'><div>
<u>THEORY</u> :<br/><br/>
At the end of this step, we will have identified.
</div></div>

<div class='notice'><div>
At the end of this step, we will have identified.
</div></div>


<h3 class="subtitle">Web Authentification</h3>
<p>
Some web application give tips if the account exists or not when the error message is different when the login or password are wrong.
</p>


<br/>
<h2 class="title">Password Policy</h2>
<p>
</p>

<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>polenum </span>
</pre>


<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>enum4linux </span>
</pre>



<br/>
<h2 class="title">Conclusion</h2>
<p>
</p>

<br/>
<h2 class="title">Sources:</h2>
<ul>
<li>- <a href='https://github.com/nirajkharel/AD-Pentesting-Notes' target='_blank'>https://github.com/nirajkharel/AD-Pentesting-Notes</a></li>
</ul>

<br/>
<h2 class="title">Tools:</h2>
<ul>
<li>[1] <a href='https://github.com/ropnop/kerbrute' target='_blank'>https://github.com/ropnop/kerbrute</a></li>
<li>[2] <a href='https://github.com/urbanadventurer/username-anarchy' target='_blank'>https://github.com/urbanadventurer/username-anarchy</a></li>
<li>[2] <a href='https://github.com/Wh1t3Fox/polenum/' target='_blank'>https://github.com/Wh1t3Fox/polenum/</a></li>
</ul>

<br/>
<br/>
