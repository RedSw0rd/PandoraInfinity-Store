<table class="tt-header">
<tr>
<td class="categorie">Category:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Date:</td>
<td class="date-text">23/06/2018</td>
</tr>
</table>
<div class="tt-header-title">User Enumeration</div>
<table class="tt-header">
<tr>
<td class="categorie">Author:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Lang</td>
<td class="date-text">FR</td>
</tr>
</table>

<div class="sommaire">
</div>

<h2 class="title">Introduction</h2>
<p>
Once a foothold is gained in the network under audit, the pentester’s primary objective to compromise the domain is to obtain a valid login/password pair, ideally with administrative priv>
With these credentials, the pentester will have the ability to perform a deeper enumeration step to retrieve all the information needed to become the domain administrator.
</p>
