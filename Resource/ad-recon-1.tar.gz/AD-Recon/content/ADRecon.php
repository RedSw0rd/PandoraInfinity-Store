<table class="tt-header">
<tr>
<td class="categorie">Category:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Date:</td>
<td class="date-text">23/06/2018</td>
</tr>
</table>
<div class="tt-header-title">Domain Credentials Hunting</div>
<table class="tt-header">
<tr>
<td class="categorie">Author:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Lang</td>
<td class="date-text">FR</td>
</tr>
</table>

<div class="sommaire">
</div>




<h2 class="title">Introduction</h2>
<p>
Once a foothold is gained in the network under audit, the first step will be to performs a recon/scanning phase.<br/>
While this step, the pentester need to identify exaustivly all Windows system into the same network and their systems versions.
</p>

<h3 class="subtitle">Pre-requis</h2>
<p>
Access into the local network.
</p>

<h3 class="subtitle">Context</h2>
<p>
Thise stage don't need any credentials.
</p>





<h2 class="title">Windows Hosts Discovery</h2>
<p>
All Windows system must be discovered.
</p>


<h3 class="subtitle">Passive recon</h2>
<p>
The ultimate first step will be always to listen the network before sending any packet.<br/>
Analysing network trafic can provide many informations.
</p>

<br/>

<p>
To identify many Windows Workstation, wen can use tcpdump :
</p>
<pre class="cmdoutput-win">
# tcpdump -i eth0 -n broadcast and \( port 137 or port 138 or port 445 or port 5353 or port 5355 \)
...
15:13:19.385209 IP 192.168.1.20.137 > 192.168.1.255.137: UDP, length 50
...
15:15:29.650182 IP 192.168.1.90.137 > 192.168.1.255.137: UDP, length 50
15:15:59.398605 IP 192.168.1.20.138 > 192.168.1.255.138: UDP, length 207
...
</pre>

<p>
We can also use responder in analysis mode :
</p>
<pre class="cmdoutput-win">
# responder -I eth0 -A
...
[Analyze mode: MDNS] Request by 192.168.1.90 for A94B78000000.local, ignoring
...
[Analyze mode: LLMNR] Request by fe80::37cc:55b5:beab:2f90 for A94B78000000, ignoring
[Analyze mode: LLMNR] Request by 192.168.1.90 for A94B78000000, ignoring
...
[Analyze mode: NBT-NS] Request by 192.168.1.90 for A94B78000000, ignoring
</pre>

<p>
Some Linux box with Samba service or using MDNS can appears too.
</p>

<br/>

<p>
Passive recon have the advantage to stay stealthy and to obtain a good idea about the network activity whitout sending any packets.<br/>
Unfortenly, to have more details and to be more exaustif, we need to performes a active recon phase too.
</p>


<h3 class="subtitle">Active Recon</h2>

<p>
To identify all windows machine in the 192.168.1.0/24 network, we can use nbtscan :
</p>
<pre class="cmdoutput-win">
# nbtscan -r 192.168.1.0/24
</pre>

<p>
The result will provide all systeme running netbios with their netbios tables.
Netbios table give us the role of some systeme windows such as a MSSQL server or Domain Controler.
</p>

<p>
Note that all Linux systeme running Samble will response with an address MAC set to 00-00-00-00-00-00.<br/>
So, all others systeme are Windows box.
</p>

<p>
Another approch to identify all windows machine will use the well know nmap :
</p>
<pre class="cmdoutput-win">
# nmap -sS -Pn --open -p137,139,445 192.168.1.0/24
</pre>

<br/>

<p>
At the end of this step, we will have a list with all Windows Hosts in the audited network.
</p>


<h2 class="title">Operating system identification</h2>
<p>
Now, we need to identify the OS for all Windows IP previsioulsy detected.
</p>

<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb-os-discovery 192.168.1.0/24
</pre>

<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb-os-discovery TARGET IP
</pre>

<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 -O TARGET IP
</pre>


<h2 class="title">Disabled SMB Signing Discovery</h2>
<p>
All Windows hosts with SMB signing disabled must be discovered. These hosts will permit to lauch some attacks later.<br/>
We can scan the whole network or scan each IP, one by one.
</p>

<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb2-security-mode 192.168.1.0/24
</pre>


<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb2-security-mode TARGET_IP
</pre>

<p>
At the end of this step, we will have a list with all Windows system with SMB signing to false.
</p>


<h2 class="title">Domain Controler Discovery</h2>
<p>
</p>
<pre class="cmdoutput-win">
# nmap -Pn --open -p389 192.168.1.0/24
</pre>





<h2 class="title">Infamous Vulnerability Discovery</h2>
<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -Pn -p137,139,445 --script smb-vuln-ms10-054 192.168.1.0/24
</pre>




<h2 class="title">Network Shares Discovery</h2>
<p>
To enum shared folders/resources efficasly in a host, we need valid credentials.
Even without credentials, we can try to discover permissive shared folder across the network.
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb-enum-shares 192.168.1.0/24
</pre>

<p>
smb-enum-shares will try to dump the shared resources list if anonymous connection is allowed.
If false, it will use well known shared list name to discover their presence by analysis the smb response.
</p>


<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb-enum-shares TARGET_IP
</pre>







<h2 class="title">One shot</h2>



<p>
</p>
<pre class="cmdoutput-win">
# nmap -sS -p137,139,445 --script smb* 192.168.1.0/24
</pre>



<p>
</p>
<pre class="cmdoutput-win">
# enum4linux
</pre>




<p>
</p>
<pre class="cmdoutput-win">
# runfinger
...
[SMB2]:['192.168.1.20', Os:'Windows 10/Server 2016/2022 (check build)', Build:'18362', Domain:'THANOS', Bootime: 'Unknown', Signing:'False', RDP:'False', SMB1:'True', MSSQL:'False']
[SMB1]:['192.168.1.20', Os:'Windows 10 Education 18363', Domain:'WORKGROUP', Signing:'False', Null Session: 'False', RDP:'False', MSSQL:'False']
[SMB2]:['192.168.1.90', Os:'Windows 10/Server 2016/2022 (check build)', Build:'22621', Domain:'SPECTRE', Bootime: 'Unknown', Signing:'False', RDP:'True', SMB1:'False', MSSQL:'False']
...
</pre>


<p>
With runfinger, we can obtain all essentials informations in one command.<br/>
Runfinger will display response from SMBv1 query if enabled and from SMBv2. We can see if Signing is enabled or not, the operating systeme provided.
</p>






<h2 class="title">Conclusion</h2>

<p>
At the end, we have these informations :<br/><br/>
- All Active Windows Hosts IPs<br/>
- All Domain Controler IPs<br/>
- The operating system<br/>
- The SMB signing status<br/>
- The presence of ms10-054 vulnerability<br/>
</p>
