<script>
function copyToClipboard(element) {
        navigator.clipboard.writeText(element.textContent);
}
</script>
<table class="tt-header">
<tr>
<td class="categorie">Category:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Date:</td>
<td class="date-text">23/06/2018</td>
</tr>
</table>
<div class="tt-header-title">Reconnaissance phase</div>
<table class="tt-header">
<tr>
<td class="categorie">Author:</td>
<td class="categorie-text">ACTIVE DIRECTORY</td>
<td class="date">Lang</td>
<td class="date-text">FR</td>
</tr>
</table>

<div class="summary">
<span class='t'>1 - <a href="#1">Introduction</a></span>
<span class='st'>1.1 - <a href="#1.1">Pre-requis</a></span>
<span class='st'>1.2 - <a href="#1.2">Context</a></span>
</div>

<br/>
<a id="1"></a>
<h2 class="title">Introduction</h2>
<p>
Once a foothold is gained in the network under audit, the first step will be to performs a recon/scanning phase.<br/>
While this step, the pentester need to identify exaustivly all Windows system into the same network and their systems versions.
</p>

<a id="1.1"></a>
<h3 class="subtitle">Pre-requis</h3>
<p>
Access into the local network.
</p>

<a id="1.2"></a>
<h3 class="subtitle">Context</h3>
<p>
Thise stage don't need any credentials.
</p>

<br/>
<h2 class="title">Windows Hosts Discovery</h2>
<p>
All Windows system must be discovered.
</p>

<h3 class="subtitle">Passive recon</h3>
<p>
The ultimate first step will be always to listen the network before sending any packet.<br/>
Analysing network trafic can provide many informations.
</p>

<p>
To identify many Windows Workstation, wen can use tcpdump :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>tcpdump -i eth0 -n broadcast and \( port 137 or port 138 or port 445 or port 5353 or port 5355 \)</span>
...
15:13:19.385209 IP 192.168.1.20.137 > 192.168.1.255.137: UDP, length 50
...
15:15:29.650182 IP 192.168.1.90.137 > 192.168.1.255.137: UDP, length 50
15:15:59.398605 IP 192.168.1.20.138 > 192.168.1.255.138: UDP, length 207
...
</pre>

<p>
We can also use responder in analysis mode :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>responder -I eth0 -A</span>
...
[Analyze mode: MDNS] Request by 192.168.1.90 for A94B78000000.local, ignoring
...
[Analyze mode: LLMNR] Request by fe80::37cc:55b5:beab:2f90 for A94B78000000, ignoring
[Analyze mode: LLMNR] Request by 192.168.1.90 for A94B78000000, ignoring
...
[Analyze mode: NBT-NS] Request by 192.168.1.90 for A94B78000000, ignoring
</pre>

<p>
Some Linux box with Samba service or using MDNS can appears too.
</p>
<p>
Passive recon have the advantage to stay stealthy and to obtain a good idea about the network activity whitout sending any packets.<br/>
Unfortenly, to have more details and to be more exaustif, we need to performes a active recon phase too.
</p>


<h3 class="subtitle">Active Recon</h3>

<p>
To identify all windows machine in the 192.168.1.0/24 network, we can use nbtscan :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nbtscan -qvhr 192.168.1.0/24</span>

NetBIOS Name Table for Host 192.168.1.20:

Name             Service          Type
----------------------------------------
THANOS           Workstation Service
WORKGROUP        Domain Name
THANOS           File Server Service
WORKGROUP        Browser Service Elections
WORKGROUP        Master Browser
__MSBROWSE__  Master Browser

Adapter address: 1c:1b:0d:93:c3:0b
----------------------------------------

NetBIOS Name Table for Host 192.168.1.51:


Name             Service          Type
----------------------------------------
BACKUPCENTER     Workstation Service
BACKUPCENTER     Messenger Service
BACKUPCENTER     File Server Service
WORKGROUP        Domain Name
WORKGROUP        Browser Service Elections

Adapter address: <span style='color:orange;'>00:00:00:00:00:00</span>
----------------------------------------
...
...
</pre>


<table class='parameter'>
<tr><td class='flag'>-q</td><td class='desc'>Silent mode</td></tr>
<tr><td class='flag'>-v</td><td class='desc'>Verbose mode ???</td></tr>
<tr><td class='flag'>-h</td><td class='desc'>Human readable</td></tr>
<tr><td class='flag'>-r</td><td class='desc'>Silent mode</td></tr>
</table>


<p>
The result will provide all systeme running netbios with their netbios tables.
Netbios table give us the role of some systeme windows such as a MSSQL server or Domain Controler.
</p>
<p>
Note that all Linux systeme running Samble will response with an address MAC set to 00:00:00:00:00:00.<br/>
So, all others systeme are Windows box.
</p>

<p>
Another approch to identify all windows machine will use the well know nmap :
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -PS -n --open -p139,445 192.168.1.0/24</span>
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-01-08 22:21 CET
Nmap scan report for 192.168.1.20
Host is up (0.00021s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 1C:1B:0D:93:C3:0B (Giga-byte Technology)

Nmap scan report for 192.168.1.50
Host is up (0.00034s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 90:09:D0:08:3B:B7 (Synology Incorporated)

Nmap scan report for 192.168.1.51
Host is up (0.00015s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 00:11:32:89:2C:3C (Synology Incorporated)

Nmap scan report for 192.168.1.90
Host is up (0.00032s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 58:47:CA:70:2B:B2 (Shenzhen Meigao Electronic Equipment)

Nmap done: 256 IP addresses (16 hosts up) scanned in 5.09 seconds
</pre>

<div class='notice'><div>
At the end of this step, we will have a list with all system running netbios/smb services.<br/>
This list can contains some Linux box running samba services.
</div></div>



<p>
</p>

<br/>
<h2 class="title">Operating system identification</h2>
<p>
Now, we need to identify the OS for all Windows IP previsioulsy detected.
</p>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -p137,139,445 --script smb-os-discovery 192.168.1.0/24</span>
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-01-08 22:24 CET
Nmap scan report for Thanos (192.168.1.20)
Host is up (0.00021s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 1C:1B:0D:93:C3:0B (Giga-byte Technology)

Host script results:
| smb-os-discovery:
|   OS: <span style='color:lime;'>Windows 10 Education 18363 (Windows 10 Education 6.3)</span>
|   OS CPE: cpe:/o:microsoft:windows_10::-
|   Computer name: THANOS
|   NetBIOS computer name: THANOS\x00
|   Workgroup: WORKGROUP\x00
|_  System time: 2025-01-08T22:24:16+01:00
...
...
...
</pre>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -p137,139,445 --script smb-os-discovery TARGET IP</span>
</pre>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -Pn -sS -O --osscan-guess 192.168.1.90</span>
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-01-08 22:35 CET
Nmap scan report for Spectre (192.168.1.90)
Host is up (0.00058s latency).
Not shown: 995 closed tcp ports (reset)
PORT     STATE SERVICE
135/tcp  open  msrpc
139/tcp  open  netbios-ssn
445/tcp  open  microsoft-ds
3389/tcp open  ms-wbt-server
5357/tcp open  wsdapi
MAC Address: 58:47:CA:70:2B:B2 (Shenzhen Meigao Electronic Equipment)
Device type: general purpose
Running: <span style='color:lime;'>Microsoft Windows 10</span>
OS CPE: cpe:/o:microsoft:windows_10:1703
OS details: <span style='color:lime;'>Microsoft Windows 10 1703</span>
Network Distance: 1 hop

OS detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 21.06 seconds
</pre>

<div class='notice'><div>
At the end of this step, we will have a list with all system running netbios/smb services with the operating system.
</div></div>


<br/>
<h2 class="title">Disabled SMB Signing Discovery</h2>
<p>
All Windows hosts with SMB signing disabled must be discovered. These hosts will permit to lauch some attacks later.<br/>
We can scan the whole network or scan each IP, one by one.
</p>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -Pn -sS -p139,445 --open --script smb2-security-mode 192.168.1.0/24</span>
Starting Nmap 7.94SVN ( https://nmap.org ) at 2025-01-08 22:38 CET
Nmap scan report for Thanos (192.168.1.20)
Host is up (0.00023s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 1C:1B:0D:93:C3:0B (Giga-byte Technology)

Host script results:
| smb2-security-mode:
|   3:1:1:
|_    <span style='color:lime;'>Message signing enabled but not required</span>

Nmap scan report for DeathStar (192.168.1.50)
Host is up (0.00034s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 90:09:D0:08:3B:B7 (Synology Incorporated)

Host script results:
| smb2-security-mode:
|   3:1:1:
|_    <span style='color:lime;'>Message signing enabled but not required</span>

Nmap scan report for 192.168.1.51
Host is up (0.00016s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 00:11:32:89:2C:3C (Synology Incorporated)

Host script results:
| smb2-security-mode:
|   2:0:2:
|_    <span style='color:lime;'>Message signing enabled but not required</span>

Nmap scan report for Spectre (192.168.1.90)
Host is up (0.00038s latency).

PORT    STATE SERVICE
139/tcp open  netbios-ssn
445/tcp open  microsoft-ds
MAC Address: 58:47:CA:70:2B:B2 (Shenzhen Meigao Electronic Equipment)

Host script results:
| smb2-security-mode:
|   3:1:1:
|_    <span style='color:lime;'>Message signing enabled but not required</span>

Nmap done: 256 IP addresses (16 hosts up) scanned in 5.27 seconds
</pre>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -p137,139,445 --script smb2-security-mode TARGET_IP</span>
</pre>

<div class='notice'><div>
At the end of this step, we will have a list with all Windows system with SMB signing to false.
</div></div>


<br/>
<h2 class="title">Domain Controler Discovery</h2>
<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -Pn -sS --open -p389 192.168.1.0/24</span>
</pre>

<div class='notice'><div>
At the end of this step, we will have a list of all domain controler.
</div></div>



<br/>
<h2 class="title">Infamous Vulnerability Discovery</h2>
<p>
</p>




<h3 class="subtitle">MS08-067</h3>
<p>
</p>



<h3 class="subtitle">MS10-054</h3>
<p>
</p>


<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -Pn -p139,445 --open --script smb-vuln-ms10-054 192.168.1.0/24</span>
</pre>



<h3 class="subtitle">MS14-025</h3>
<p>
</p>



<div class='notice'><div>
At the end of this step, we will have identified if some hosts are vulnerable to well known exploit.
</div></div>



<br/>
<h2 class="title">Network Shares Discovery</h2>
<p>
To enum shared folders/resources efficasly in a host, we need valid credentials.
Even without credentials, we can try to discover permissive shared folder across the network.
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -p139,445 --open --script smb-enum-shares 192.168.1.0/24</span>
</pre>

<p>
smb-enum-shares will try to dump the shared resources list if anonymous connection is allowed.
If false, it will use well known shared list name to discover their presence by analysis the smb response.
</p>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -p139,445 --open --script smb-enum-shares TARGET_IP</span>
</pre>

<div class='notice'><div>
At the end of this step, we will have identified all shared folder accessible without permissions.
</div></div>


<br/>
<h2 class="title">One shot</h2>
<p>
Previoulsy, we have used a tool to find intersting informations one bye one.<br/>
We can also use other tools or command line modified to find many information at once.
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>nmap -sS -p139,445 --open --script smb* 192.168.1.0/24</span>
</pre>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>enum4linux</span>
</pre>

<p>
</p>
<pre class="cmdoutput-linux">
# <span class='cmdline' onclick='copyToClipboard(this)'>runfinger</span>
...
[SMB2]:['192.168.1.20', Os:'Windows 10/Server 2016/2022 (check build)', Build:'18362', Domain:'THANOS', Bootime: 'Unknown', Signing:'False', RDP:'False', SMB1:'True', MSSQL:'False']
[SMB1]:['192.168.1.20', Os:'Windows 10 Education 18363', Domain:'WORKGROUP', Signing:'False', Null Session: 'False', RDP:'False', MSSQL:'False']
[SMB2]:['192.168.1.90', Os:'Windows 10/Server 2016/2022 (check build)', Build:'22621', Domain:'SPECTRE', Bootime: 'Unknown', Signing:'False', RDP:'True', SMB1:'False', MSSQL:'False']
...
</pre>
<p>
With runfinger, we can obtain all essentials informations in one command.<br/>
Runfinger will display response from SMBv1 query if enabled and from SMBv2. We can see if Signing is enabled or not, the operating systeme provided.
</p>


<br/>
<h2 class="title">Conclusion</h2>
<p>
At the end, we have these informations :<br/><br/>
- All Active Windows Hosts IPs<br/>
- All Domain Controler IPs<br/>
- The operating system<br/>
- The SMB signing status<br/>
- The presence of ms10-054 vulnerability<br/>
</p>

<br/>
<h2 class="title">Sources:</h2>
<ul>
<li>- <a href='https://github.com/nirajkharel/AD-Pentesting-Notes' target='_blank'>https://github.com/nirajkharel/AD-Pentesting-Notes</a></li>
</ul>

<br/>
<h2 class="title">Tools:</h2>
<ul>
<li>[1] <a href='https://github.com/lgandx/Responder' target='_blank'>https://github.com/lgandx/Responder</a></li>
<li>[2] <a href='https://www.kali.org/tools/nbtscan/' target='_blank'>https://www.kali.org/tools/nbtscan/</a></li>
<li>[2] <a href='https://github.com/cddmp/enum4linux-ng' target='_blank'>https://github.com/cddmp/enum4linux-ng</a></li>
</ul>

<br/>
<br/>
