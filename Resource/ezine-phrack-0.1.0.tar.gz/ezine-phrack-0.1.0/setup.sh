#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

ezineDirPath="/var/lib/pandora/usr/resources/ezine"
dbPath="/var/lib/pandora/db/resource/ezine.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# EZINE NAME
###########################################################################

ezinename="PHRACK"
ezinedesc="By hacker for hacker"

if [[ ! -e "$ezineDirPath/$ezinename" ]]
then
	#
	mkdir "$ezineDirPath/$ezinename"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO EZINE_NAME (NAME, DESC) VALUES ('$ezinename', '$ezinedesc')"
fi

###########################################################################
# EZINE FILE
###########################################################################

filename="1-1.txt"
issue="1"
filenum="1"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="1-2.txt"
issue="1"
filenum="2"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="1-3.txt"
issue="1"
filenum="3"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="33-8.txt"
issue="33"
filenum="8"
desc="TCP/IP: A Tutorial Part 1 of 2"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="34-8.txt"
issue="34"
filenum="8"
desc="TCP/IP: A Tutorial Part 2 of 2"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="41-8.txt"
issue="41"
filenum="8"
desc="TTY Spoofing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="49-8.txt"
issue="49"
filenum="8"
desc="Introduction to CGI and CGI vulnerabilities"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="49-14.txt"
issue="49"
filenum="14"
desc="Smashing The Stack For Fun And Profit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="49-15.txt"
issue="49"
filenum="15"
desc="TCP port Stealth Scanning"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="50-5.txt"
issue="50"
filenum="5"
desc="Linux TTY hijacking"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="50-7.txt"
issue="50"
filenum="7"
desc="SNMP insecurities"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="51-8.txt"
issue="51"
filenum="8"
desc="Shared Library Redirection"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="51-11.txt"
issue="51"
filenum="11"
desc="The Art of Scanning"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="52-5.txt"
issue="52"
filenum="5"
desc="Everything a hacker needs to know about getting busted"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="52-16.txt"
issue="52"
filenum="16"
desc="Piercing Firewalls"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="53-5.txt"
issue="53"
filenum="3"
desc="An Overview of Internet Routing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="53-7.txt"
issue="53"
filenum="7"
desc="A Stealthy Windows Keylogger"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="54-9.txt"
issue="54"
filenum="9"
desc="Remote OS detection via TCP/IP Stack Fingerprinting"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="54-10.txt"
issue="54"
filenum="10"
desc="Defeating Sniffers and Intrusion Detection Systems"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="55-5.txt"
issue="55"
filenum="5"
desc="A Real NT Rootkit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="55-15.txt"
issue="55"
filenum="15"
desc="Win32 Buffer Overflows (Location, Exploitation and Prevention)"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="56-8.txt"
issue="56"
filenum="8"
desc="Smashing C++ VPTRs"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="56-9.txt"
issue="56"
filenum="9"
desc="Backdooring binary objects"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="56-13.txt"
issue="56"
filenum="13"
desc="Introduction to PAM"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="56-14.txt"
issue="56"
filenum="14"
desc="Exploiting Non-adjacent Memory Spaces"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="57-5.txt"
issue="57"
filenum="5"
desc="IA64 shellcode"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="57-7.txt"
issue="57"
filenum="7"
desc="ICMP based OS fingerprinting"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="57-11.txt"
issue="57"
filenum="11"
desc="Holistic approaches to attack detection"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="57-14.txt"
issue="57"
filenum="14"
desc="Architecture spanning shellcode"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="57-15.txt"
issue="57"
filenum="15"
desc="Writing ia32 alphanumeric shellcodes"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="58-4.txt"
issue="58"
filenum="4"
desc="Advanced return-into-lib(c) exploits (PaX case study)"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="58-5.txt"
issue="58"
filenum="5"
desc="Runtime binary encryption"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="58-6.txt"
issue="58"
filenum="6"
desc="Advances in kernel hacking"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="58-7.txt"
issue="58"
filenum="7"
desc="Linux on-the-fly kernel patching without LKM"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="59-5.txt"
issue="59"
filenum="5"
desc="Advances in kernel hacking II"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="59-6.txt"
issue="59"
filenum="6"
desc="Defeating Forensic Analysis on Unix"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="59-9.txt"
issue="59"
filenum="9"
desc="Bypassing PaX ASLR protection"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="59-14.txt"
issue="59"
filenum="14"
desc="Writing Linux Kernel Keylogger"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="60-6.txt"
issue="60"
filenum="6"
desc="Smashing The Kernel Stack For Fun And Profit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="60-8.txt"
issue="60"
filenum="8"
desc="Static Kernel Patching"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="60-10.txt"
issue="60"
filenum="10"
desc="Basic Integer Overflows"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="60-11.txt"
issue="60"
filenum="11"
desc="SMB/CIFS By The Root"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="60-14.txt"
issue="60"
filenum="14"
desc="Traffic Lights"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-6.txt"
issue="61"
filenum="6"
desc="Advanced Doug Lea\'s malloc exploits"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-7.txt"
issue="61"
filenum="7"
desc="Hijacking Linux Page Fault Handler"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-8.txt"
issue="61"
filenum="8"
desc="The Cerberus ELF interface"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-9.txt"
issue="61"
filenum="9"
desc="Polymorphic Shellcode Engine"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-10.txt"
issue="61"
filenum="10"
desc="Infecting Loadable Kernel Modules"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-11.txt"
issue="61"
filenum="11"
desc="Building IA32 \'Unicode-Proof\' Shellcodes"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-12.txt"
issue="61"
filenum="12"
desc="Fun with the Spanning Tree Protocol"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-13.txt"
issue="61"
filenum="13"
desc="Hacking the Linux Kernel Network Stack"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="61-14.txt"
issue="61"
filenum="14"
desc="Kernel Rootkit Experiences & the Future"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-5.txt"
issue="62"
filenum="5"
desc="Bypassing Win BO Protection"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-6.txt"
issue="62"
filenum="6"
desc="Kernel Mode Backdoor for NT"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-7.txt"
issue="62"
filenum="7"
desc="Advances in Windows Shellcode"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-8.txt"
issue="62"
filenum="8"
desc="Remote Exec"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-9.txt"
issue="62"
filenum="9"
desc="UTF8 Shellcode"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-10.txt"
issue="62"
filenum="10"
desc="Attacking Apache Modules"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-11.txt"
issue="62"
filenum="11"
desc="Radio Hacking"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-12.txt"
issue="62"
filenum="12"
desc="Win32 Portable Userland Rootkit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-13.txt"
issue="62"
filenum="13"
desc="Bypassing Windows Personal FW\'s"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="62-14.txt"
issue="62"
filenum="14"
desc="A Dynamic Polyalphabetic Substitution Cipher"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-10.txt"
issue="63"
filenum="10"
desc="Hacking Grub for Fun & Profit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-11.txt"
issue="63"
filenum="11"
desc="Advanced antiforensics : SELF"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-12.txt"
issue="63"
filenum="12"
desc="Process Dump and Binary Reconstruction"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-13.txt"
issue="63"
filenum="13"
desc="Next-Gen. Runtime Binary Encryption"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-14.txt"
issue="63"
filenum="14"
desc="Shifting the Stack Pointer"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-15.txt"
issue="63"
filenum="15"
desc="NT Shellcode Prevention Demystified"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-17.txt"
issue="63"
filenum="17"
desc="Hacking with Embedded Systems"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-18.txt"
issue="63"
filenum="18"
desc="Process Hiding & The Linux Scheduler"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="63-19.txt"
issue="63"
filenum="19"
desc="Breaking Through a Firewall"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="64-5.txt"
issue="64"
filenum="5"
desc="Hijacking RDS TMC traffic information signal"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi


#

filename="64-6.txt"
issue="64"
filenum="6"
desc="Attacking the Core: Kernel Exploitation Notes"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="64-12.txt"
issue="64"
filenum="12"
desc="Hacking deeper in the system"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="64-13.txt"
issue="64"
filenum="13"
desc="Remote blind TCP/IP spoofing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="64-15.txt"
issue="64"
filenum="15"
desc="The art of exploitation: Autopsy of cvsxpl"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="65-4.txt"
issue="65"
filenum="4"
desc="Stealth Hooking: another way to subvert the Windows kernel"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="65-12.txt"
issue="65"
filenum="12"
desc="The art of exploitation: Technical analysis of Samba WINS overflow"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi
