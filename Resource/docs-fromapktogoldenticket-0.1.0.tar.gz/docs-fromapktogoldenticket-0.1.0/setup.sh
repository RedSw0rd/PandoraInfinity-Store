#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

documentDirPath="/var/www/pandora/usr/res/document"
dbPath="/var/lib/pandora/db/resource/document.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

name="From APK to Golden Ticket"
filename="From-apk-to-golden-ticket.pdf"
newFilename=$(echo $(echo $(shuf -i 1-100000 -n 1)$(date +%s) | sha256sum | awk '{ print $1 }')_"$filename")
category="SOCIAL ENGINEERING"
desc="Owning an Android smartphone and gaining Domain Admin rights and more"

if [[ -e "content/$filename" ]]
then
        hash=$(md5sum "content/$filename" | awk '{ print $1 }')
        hash_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM DOCUMENT WHERE HASH = '$hash';")
        if [ "$hash_exists" -ne 0 ]
	then
		echo "|!| File $filename already exists in $documentDirPath";
	else
		mv "content/$filename" "$documentDirPath/$newFilename"

		if [[ -e "$documentDirPath/$newFilename" ]]
		then
			category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM DOCUMENT_CATEGORY WHERE NAME = '$category';")
			if [ "$category_exists" -eq 0 ]
			then
				# CREATE NEW CATEGORY
				sqlite3 "$dbPath" "INSERT INTO DOCUMENT_CATEGORY (NAME) VALUES ('$category');"
			fi

			filesize=$(stat -c%s "$documentDirPath/$newFilename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO DOCUMENT (NAME, DESC, CATEGORY, TYPE, SIZE, PATH, HASH, DATE) VALUES ('$name', '$desc', '$category', 'PDF', '$filesize', '/usr/res/document/$newFilename', '$hash', '$date');"
			echo "|+| Document $filename was successfully installed"
		fi
	fi
fi
