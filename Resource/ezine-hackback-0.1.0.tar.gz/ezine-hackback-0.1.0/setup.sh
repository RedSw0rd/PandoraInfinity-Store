#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

ezineDirPath="/var/lib/pandora/usr/resources/ezine"
dbPath="/var/lib/pandora/db/resource/ezine.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"


###########################################################################
# EZINE NAME
###########################################################################

ezinename="HACKBACK"
ezinedesc="Phineas Fisher hacks"

if [[ ! -e "$ezineDirPath/$ezinename" ]]
then
	#
	mkdir "$ezineDirPath/$ezinename"

	# SAVE IN DB
	sqlite3 "$dbPath" "INSERT INTO EZINE_NAME (NAME, DESC) VALUES ('$ezinename', '$ezinedesc')"
fi

###########################################################################
# EZINE FILE
###########################################################################

filename="hackback-1.txt"
issue="1"
filenum="1"
desc="HackBack: A DIY Guide for those without the patience to wait for whistleblowers"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="hackback-2.txt"
issue="2"
filenum="1"
desc="HackBack: A DIY Guide"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi

#

filename="hackback-3.txt"
issue="3"
filenum="1"
desc="HackBack: A DIY guide to robbing banks"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
	then
		echo "|!| File $filename already exists in $ezineDirPath/$ezinename";
	else
		mv "content/$filename" "$ezineDirPath/$ezinename/$filename"

		if [[ -e "$ezineDirPath/$ezinename/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$ezineDirPath/$ezinename/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO EZINE (NAME, ISSUE, FILENUM, DESC, SIZE, PATH, DATE) VALUES ('$ezinename', '$issue', '$filenum', '$desc', '$filesize', '$ezineDirPath/$ezinename/$filename', '$date');"

			echo "|+| Ezine File $filename was successfully installed"
		fi
	fi
fi
