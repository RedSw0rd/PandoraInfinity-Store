#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

documentDirPath="/var/www/pandora/usr/res/document"
dbPath="/var/lib/pandora/db/resource/document.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

name="Smash the stack"
filename="smashthestack.pdf"
newFilename=$(date +%s | sha256sum | awk '{ print $1 }')_$filename
category="SYSTEM HACKING"
desc="Smashing the Stack for Fun and Profit - Originally written by Aleph One and heavy formatting done by avicoder"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$documentDirPath/$newFilename" ]]
	then
		echo "|!| File $filename already exists in $documentDirPath";
	else
		mv "content/$filename" "$documentDirPath/$newFilename"

		if [[ -e "$documentDirPath/$newFilename" ]]
		then
                        #
                        category_exists=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM DOCUMENT_CATEGORY WHERE NAME = '$category';")
                        if [ "$category_exists" -eq 0 ]
                        then
                                # CREATE NEW CATEGORY
                                sqlite3 "$dbPath" "INSERT INTO DOCUMENT_CATEGORY (NAME) VALUES ('$category');"
                        fi

			#
			filesize=$(stat -c%s "$documentDirPath/$newFilename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO DOCUMENT (NAME, DESC, CATEGORY, TYPE, SIZE, PATH, DATE) VALUES ('$name', '$desc', '$category', 'PDF', '$filesize', '/usr/res/document/$newFilename', '$date');"

                        echo "|+| Document $filename was successfully installed"
                        
		fi
	fi
fi
