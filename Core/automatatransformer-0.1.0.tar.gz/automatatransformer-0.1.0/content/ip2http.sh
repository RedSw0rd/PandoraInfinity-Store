#!/bin/bash

if [ -z "$1" ] || [ ! -f "$1" ]; then
    exit 1
fi

# IP -> http://IP
grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' "$1" | awk '{
    gsub(/[[:space:]]/, "", $0)
    if ($0 == "") next
    print "http://" $0
}' | sort -u

exit 0
