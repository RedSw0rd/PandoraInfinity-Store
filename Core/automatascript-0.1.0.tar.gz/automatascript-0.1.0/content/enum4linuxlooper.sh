#!/bin/bash

INPUT_FILE="${1:-}"

if [[ -z "${INPUT_FILE}" ]]; then
        echo "[!] Error: No input file provided." >&2
        echo "Usage: $0 <path_to_host_list>" >&2
        exit 1
fi

if [[ ! -f "${INPUT_FILE}" ]]; then
    echo "[!] Error: Input file '${INPUT_FILE}' not found." >&2
    exit 1
fi

if ! command -v jq &>/dev/null; then
    echo "[!] Error: 'jq' is required." >&2
    exit 1
fi

TMP_DIR=$(mktemp -d /tmp/enum4linux_XXXXXX)
trap 'rm -rf "${TMP_DIR}"' EXIT

while read -r TARGET || [[ -n "${TARGET}" ]]; do
    TARGET=$(echo "${TARGET}" | xargs)
    [[ -z "${TARGET}" || "${TARGET}" =~ ^# ]] && continue

    TMP_JSON="${TMP_DIR}/${TARGET}.json"

    enum4linux-ng -oJ "${TMP_JSON}" -U "${TARGET}" &>/dev/null

    # Si l'outil echoue ou sort un fichier vide, on met un fallback minimal pour ne pas casser le tableau jq
    if [[ ! -s "${TMP_JSON}" ]]; then
        echo "{\"target\": {\"host\": \"${TARGET}\"}, \"status\": \"failed\"}" > "${TMP_JSON}"
    fi

done < "${INPUT_FILE}"

# Fusion brute dans un seul tableau JSON
jq -s '.' "${TMP_DIR}"/*.json

exit 0
