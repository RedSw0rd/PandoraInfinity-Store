#!/bin/bash

CIDR="${1:-}"

if [[ -z "${CIDR}" ]]; then
    echo "[!] Error: No CIDR provided." >&2
    echo "Usage: $0 <CIDR>" >&2
    exit 1
fi

# Validation stricte du format IPv4 CIDR (ex: 192.168.1.0/24)
if [[ ! "${CIDR}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}/([0-9]|[1-2][0-9]|3[0-2])$ ]]; then
    echo "[!] Error: Invalid CIDR format. Expected format: X.X.X.X/Y" >&2
    exit 1
fi

naabu -duc -no-color -silent -host "${CIDR}" -host-discovery -pe
exit 0
