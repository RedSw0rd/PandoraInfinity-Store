#!/bin/bash

INPUT_FILE="${1:-}"

if [[ -z "${INPUT_FILE}" ]]; then
	echo "[!] Error: No input file provided." >&2
	echo "Usage: $0 <path_to_host_list>" >&2
	exit 1
fi

if [[ ! -f "${INPUT_FILE}" ]]; then
    echo "[!] Error: Input file '${INPUT_FILE}' not found." >&2
    exit 1
fi

naabu -duc -no-color -silent -list "${INPUT_FILE}" -host-discovery 2>/dev/null
exit 0
