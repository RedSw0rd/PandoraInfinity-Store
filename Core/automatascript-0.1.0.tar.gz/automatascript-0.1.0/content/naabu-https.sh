#!/bin/bash

INPUT_FILE="${1:-}"

if [[ -z "${INPUT_FILE}" ]]; then
	echo "[!] Error: No input file provided." >&2
	echo "Usage: $0 <path_to_host_list>" >&2
	exit 1
fi

if [[ ! -f "${INPUT_FILE}" ]]; then
    echo "[!] Error: Input file '${INPUT_FILE}' not found." >&2
    exit 1
fi

naabu -duc -no-color -silent -list "${INPUT_FILE}" -rate 500 -port 80,443,81,4433,8080,82,88,8081,12345,83,8001,9000,90,84,8443,7001,85,8888,8880,4443 -verify 2>/dev/null
exit 0
