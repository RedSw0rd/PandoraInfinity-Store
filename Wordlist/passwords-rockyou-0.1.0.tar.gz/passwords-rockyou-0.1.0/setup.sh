#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

WordlistDirPath="/var/lib/pandora/usr/wordlists/default"
dbPath="/var/lib/pandora/db/user/wordlist.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="rockyou.txt.tar.xz"
finalfilename="rockyou.txt"
desc="The famous rockyou password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$finalfilename" ]]
	then
		echo "|!| File $finalfilename already exists in $WordlistDirPath";
	else
		tar -xJf "content/$filename" -C "content/"
		mv "content/$finalfilename" "$WordlistDirPath/$finalfilename"

		if [[ -e "$WordlistDirPath/$finalfilename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$finalfilename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$finalfilename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$finalfilename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $finalfilename was successfully installed"
		fi
	fi
fi
