#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

WordlistDirPath="/var/lib/pandora/usr/wordlists/default"
dbPath="/var/lib/pandora/db/user/wordlist.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="rockyou-25.txt"
desc="Part of the rockyou password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="rockyou-50.txt"
desc="Part of the rockyou password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="rockyou-75.txt"
desc="Part of the rockyou password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi
