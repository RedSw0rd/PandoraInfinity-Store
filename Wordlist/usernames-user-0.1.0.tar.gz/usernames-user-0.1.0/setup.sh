#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

WordlistDirPath="/var/lib/pandora/usr/wordlists/default"
dbPath="/var/lib/pandora/db/user/wordlist.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="http_default_users.txt"
desc="HTTP default users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="idrac_default_user.txt"
desc="IDRAC default users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="ipmi_users.txt"
desc="IPMI users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="oracle_logins.txt"
desc="Oracle common logins"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="postgres_default_user.txt"
desc="Postgres default users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="telnet_cisco_default_user.txt"
desc="TELNET Cisco default users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="tomcat_mgr_default_users.txt"
desc="TOMCAT MGR default users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="unix_users.txt"
desc="UNIX users from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('USERLIST', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Users list $filename was successfully installed"
		fi
	fi
fi



