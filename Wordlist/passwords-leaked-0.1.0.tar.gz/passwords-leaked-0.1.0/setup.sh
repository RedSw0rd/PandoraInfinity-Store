#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

WordlistDirPath="/var/lib/pandora/usr/wordlists/default"
dbPath="/var/lib/pandora/db/user/wordlist.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="adobe100.txt"
desc="Password list from Adobe leak in 2013"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="ashley_madison.txt"
desc="Password list leaked from www.ashleymadison.com"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="carders.cc.txt"
desc="Password list leaked from carders.cc"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="elitehacker.txt"
desc="Leaked by ZF0 ZF05.txt"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="hak5.txt"
desc="Leaked by ZF0 in ZF05.txt"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="lizard_squad.txt"
desc="Password list leaked from the Lizards DDoS web application service"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="passwords_youporn2012.txt"
desc="Youporn user‘s password leaked in 2012"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="phpbb.txt"
desc="Cracked hashes from phpBB.com leaked database in 2009"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="singles.org.txt"
desc="Password list leaked from www.singles.org in 2009 (christian dating site)"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi



