#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

WordlistDirPath="/var/lib/pandora/usr/wordlists/default"
dbPath="/var/lib/pandora/db/user/wordlist.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="10k_most_common.txt"
desc="The 10 000 most common password"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="500-worst-passwords.txt"
desc="Password list based on www.whatsmypass.com/the-top-500-worst-passwords-of-all-time"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="ipmi_passwords.txt"
desc="IPMI password from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="oracle_passwords.txt"
desc="Oracle password from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="top-20-common-SSH-pwd.txt"
desc="The top 20 SSH password"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="unix_passwords.txt"
desc="UNIX password from metasploit"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi




