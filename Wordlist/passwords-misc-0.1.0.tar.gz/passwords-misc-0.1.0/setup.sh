#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

WordlistDirPath="/var/lib/pandora/usr/wordlists/default"
dbPath="/var/lib/pandora/db/user/wordlist.db"
date=$(date +%s)

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="cain.txt"
desc="Cain & Abel‘s password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="conficker.txt"
desc="Conficker worm built-in password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="darkc0de.txt"
desc="Kali‘s default password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="honeynet.txt"
desc="From a honeynet run"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="passwords_john.txt"
desc="JTR‘s password list"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$WordlistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $WordlistDirPath";
	else
		mv "content/$filename" "$WordlistDirPath/$filename"

		if [[ -e "$WordlistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$WordlistDirPath/$filename")
			count=$(awk 'END{print NR}' "$WordlistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_WORDLIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('PASSWORD', '$filename', '$filesize', '$count', '$WordlistDirPath/$filename', '$desc');"

			echo "|+| Wordlist $filename was successfully installed"
		fi
	fi
fi


