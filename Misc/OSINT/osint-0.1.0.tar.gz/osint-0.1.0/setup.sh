#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

dbPath="/var/lib/pandora/db/user/osint.db";

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

if [[ ! -e "content/OnlineInvestigationToolkit.csv" ]]
then
	echo "|E| File OnlineInvestigationToolkit.csv don't exists"
	exit
fi

while IFS='|' read -r col1 col2 col3 col4 col5 col6
do
        i=$(sqlite3 "$dbPath" "SELECT ID FROM LINK WHERE URL = \"$col3\" ;")

	if [ -z "$i" ]
	then
		echo "|+| $col2 --> $col3"
	        sqlite3 "$dbPath" "INSERT INTO LINK (CATEGORY,NAME,URL,DESC,ICON,EXTRA) VALUES (\"$col1\",\"$col2\",\"$col3\",\"$col4\",\"$col5\",\"$col6\");"
	fi

done < "content/OnlineInvestigationToolkit.csv"

exit
