#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

#
dbPath="/var/lib/pandora/db/system/store.db"

#
gitRoot="/var/lib/gitroot"
unitName="credslayer"
codename="CREDSLAYER"
icon="sniffer.gif"
projectName="CredSLayer"
projectDir="$gitRoot/$projectName"
gitRepo="https://github.com/ShellCode33/CredSLayer.git"
desc="CredSLayer goal is to look for credentials and other useful stuff in network captures"
pageName="sniffer-credslayer.php"

#
if [ ! -d "$gitRoot" ];
then
	echo "|E| ERROR : The directory $gitRoot does not exist."
	exit 1
fi

#
cd "$gitRoot"

#
if [ -d "$projectDir" ];
then
	echo "|W| WARNING: The project $projectName already exists"

	rm -rf "$projectDir"

	if [ $? -ne 0 ];
	then
		echo "|E| ERROR: Folder $projectDir still exists after rm command"
		exit 1
	fi
fi

#
echo "|+| Cloning the repository $gitRepo"
git clone "$gitRepo"
if [ $? -ne 0 ];
then
	echo "|E| ERROR: "
	exit 1
fi

#
if [ ! -d "$projectDir" ];
then
	echo "|E| ERROR: "
	exit 1
fi

#
cd "$projectDir"

#
echo "|+| Creating the virtual environment"
python3 -m venv virtenv
if [ $? -ne 0 ];
then
	echo "|E| ERROR: Failed to create the virtual environment"
	exit 1
fi

#
source virtenv/bin/activate
if [ $? -ne 0 ];
then
	echo "|E| ERROR: Failed to activate the virtual environment"
	exit 1
fi

#
echo "|+| Installing dependencies"
if [ -f requirements.txt ];
then
	pip install -r requirements.txt

	if [ $? -ne 0 ];
	then
		echo "|E| ERROR: Failed to install dependencies"
		deactivate
		exit 1
	fi
else
	echo "|!| No requirements.txt file found. No dependencies installed"
fi

#
echo "|+| Calling setup.py"
pip install .

#
deactivate

###########################################################################
#
###########################################################################

echo "|>| Starting the integration"

#
if [ -d "/var/lib/pandora/log/output/$unitName" ];
then
        echo "|!| The folder /var/lib/pandora/log/output/$unitName already exists"
else
	mkdir /var/lib/pandora/log/output/$unitName
fi

entryID=$(sqlite3 "$dbPath" "SELECT COUNT(*) FROM EXTRAUNIT WHERE CODENAME = '$codename';")
if [ "$entryID" -eq 0 ]
then
	echo "|+| Registering the unit in DB"
	date=$(date +%s)
	sqlite3 "$dbPath" "INSERT INTO EXTRAUNIT (SECTION,CODENAME,PROGNAME,DESC,PATH,DATE) VALUES ('ETHERNET','$codename','$projectName','$desc','/usr/ext/$pageName','$date');"
fi

entryID=$(sqlite3 "/var/lib/pandora/db/system/task.db" "SELECT COUNT(*) FROM TASK_ICON WHERE CODENAME = '$codename';")
if [ "$entryID" -eq 0 ]
then
	echo "|+| Registering the unit's icon"
	sqlite3 "/var/lib/pandora/db/system/task.db" "INSERT INTO TASK_ICON (CODENAME,ICON) VALUES ('$codename','$icon');"
fi

# BACK TO CURRENT FOLEDER
cd "$(dirname "${BASH_SOURCE[0]}")"

# MOVE THE PHP SCRIPT
echo "|+| Copying files"
mv content/$pageName /var/www/pandora/usr/ext/

# MOVE THE ICON
if [ -f "content/$icon" ];
then
	mv content/$icon /var/www/pandora/sys/inc/images/systray/
fi

#
chown -R www-data: "/var/lib/pandora/log/output/$unitName"
chown -R www-data: "$gitRoot/$projectName"
chown -R www-data: /var/www/pandora/usr/ext/
chown www-data: "/var/www/pandora/sys/inc/images/systray/$icon"


###########################################################################
# HELP
###########################################################################

help="
                        <div class='title'><span>INFORMATIONS > </span></div>
                        <table>
                                <tr>
                                        <td class='txt'>PROGRAM</td>
                                        <td class='val'>credslayer</td>
                                </tr>
                                <tr>
                                        <td class='txt'>DESCRIPTION</td>
                                        <td class='val'>CredSLayer goal is to look for credentials and other useful stuff in network captures. Two modes are available, pcap scanning and active processing. The latest listens for packets on a chosen interface and dynamically extracts everything it can.</td>
                                </tr>
                                <tr>
                                        <td class='txt'>AUTHOR</td>
                                        <td class='val'>ShellCode33</td>
                                </tr>
                                <tr>
                                        <td class='txt'>URL</td>
                                        <td class='val'>https://github.com/ShellCode33/CredSLayer</td>
                                </tr>
                        </table>"


entryID=$(sqlite3 "/var/lib/pandora/db/system/task.db" "SELECT COUNT(*) FROM TASK_HELP WHERE CODENAME = '$codename';")
if [ "$entryID" -eq 0 ]
then
	echo "|+| Registering the unit's help"
	sqlite3 "/var/lib/pandora/db/system/task.db" "INSERT INTO TASK_HELP (CODENAME,HELP) VALUES ('$codename','$help');"
else
	sqlite3 "/var/lib/pandora/db/system/task.db" "UPDATE TASK_HELP SET HELP = '$help' WHERE CODENAME = '$codename';"
fi

echo "|>| The project $projectName has been successfully installed, configured and integrated."

exit
