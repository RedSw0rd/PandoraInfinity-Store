<?php
$DOCROOT = $_SERVER['DOCUMENT_ROOT'];
require_once("$DOCROOT/sys/inc/php/vars.php");
require_once("$LIB_DIR_PATH/sys.php");
require_once("$LIB_DIR_PATH/chk.php");
require_once("$LIB_DIR_PATH/lsg.php");
require_once("$LIB_DIR_PATH/tlz.php");
check_login();

//
$PROGNAME = "credslayer";
$CODENAME = "CREDSLAYER";
$binpath = "$GIT_DIR_PATH/CredSLayer/credslayer/credslayer.py" ;
$initmsg = "";
$initerror = "";
$intromsg = "";
$errormsg = "";
$lastrun = "$LOG_DIR_PATH/".strtolower("$CODENAME")."/output.log" ;
$pidfile = "$RUN_DIR_PATH/".strtolower("$CODENAME").".pid" ;
$loadfile = "$RUN_DIR_PATH/".strtolower("$CODENAME").".load" ;
$logexec = "$UNITYEXEC_DIR_PATH/".strtolower("$CODENAME").".log" ;
$totrun = task_count($CODENAME);

// BINARY CHECK
if(!file_exists($binpath)) $initerror = "Program not found ($binpath)";

//
if (isset($_POST['submit']))
{
        $actiontodo = $_POST['submit'] ;

        if ($actiontodo === "SNIFF")
        {
                if (isset($_POST['interface']) && !empty($_POST['interface']))
                {
                        $interface = $_POST['interface'];
                        if(check_interface($interface))
                        {
                                $cmdline = "python3 -u $binpath -l $interface" ;

                                // RUN
                                if(empty($errormsg) && empty($initerror) && !file_exists($loadfile))
                                {
                                        task_load("$PROGNAME", "$CODENAME", base64_encode($cmdline), "", "", "", "", "", "", "LAN0", "$CODENAME", "$interface", "", "", "", "", "", "", "", "", "", "$interface", "", "", "0", "0", "{$_SESSION["username"]}", "");
                                        shell_exec("sudo $UNITY_SCRIPT_DIR_PATH/unity-exec.sh $CODENAME > /dev/null 2>&1 &") ;
                                }

                        } else $errormsg="$ERROR_INTERFACE_NOT_VALID" ;

                } else $errormsg="$ERROR_INTERFACE_NOT_SPECIFIED" ;
        }
}

if (file_exists($pidfile)) $action="STOP" ;
else $action="SNIFF" ;

//
$db = new SQLite3("$DB_DIR_PATH/global.db");
if($db)
{
        $rows = $db->query("SELECT UNITY_CONSOLE_WIDTH, UNITY_CONSOLE_HEIGHT FROM POPUP_CUSTOM_DESIGN_SETTINGS");
        $row = $rows->fetchArray();
        $unity_console_width = trim($row['UNITY_CONSOLE_WIDTH']) ;
        $unity_console_height = trim($row['UNITY_CONSOLE_HEIGHT']) ;
}
$db->close();
?>
<form method='POST' enctype='multipart/form-data' autocomplete='off'>
        <div class='pdr-toolz-header-frame <?php print $transparency_second_sub_class; ?> fadein'>
                <table>
                        <tr>
                                <td class='text'>STATUS : <span id='status'></span></td>
                                <td class='time'>TIME : <span class='timeval' id='time'>00:00:00</span></td>
                                <td class='icon'>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('term');"><img class='shine' src='<?php print $IMAGE_ICON_DIR; ?>/terminal.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('param');"><img class='shine' src='<?php print $IMAGE_ICON_DIR; ?>/parameters.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('lastrun');"><img class='shine' src='<?php print $IMAGE_ICON_DIR; ?>/process.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('history');"><img class='shine' src='<?php print $IMAGE_ICON_DIR; ?>/history.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('info');"><img class='shine' src='<?php print $IMAGE_ICON_DIR; ?>/info.png'/></a>
                                        <a href="javascript:void(0);" onclick="OpenTool('/sys/inc/php/popup/unity-console.php?n=<?php print $CODENAME; ?>', '<?php print $CODENAME; ?>', <?php print $unity_console_width; ?>, <?php print $unity_console_height; ?>);return false;"><img id='isw' class='shine' src='<?php print $IMAGE_ICON_DIR; ?>/duplicate.png'/></a>
                                </td>
                        </tr>
                </table>
        </div>
        <div class='pdr-toolz-container'>
                <div id='term' class='term <?php print $transparency_second_sub_class; ?> fadein'>
                        <div class='termframe'>
                                <div id='output' class='output <?php print "$console_class $console_font_size_class"; ?>'><?php
                                unity_reader_pid_tracker($PROGNAME, $CODENAME, "SNIFF", "STOP", $errormsg, $intromsg, $initerror, $initmsg);
                                ?>
                                </div>
                        </div>
                </div>
                <div id='param' class='param <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <table class='tr-1' style='height:10%;'>
                                <tr>
                                        <td class='txt'>Interfaces</td>
                                        <td class='input'>
                                                <select name='interface' style='width:50%;'>
                                                        <?php display_interfaces_up() ; ?>
                                                </select>
                                        </td>
                                        <td class='txt' style='width:50%;'></td>
                                </tr>
                        </table>
                </div>
                <div id='lastrun' class='lastrun <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <div class='frame'>
                                <div class='output <?php print "$console_class $console_font_size_class"; ?>'><?php display_lastrun($CODENAME); ?></div>
                        </div>
                </div>
                <div id='history' class='history <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <div id='history-output' class='history-output'>
                                <?php display_history($CODENAME); ?>
                        </div>
                </div>
                <div id='info' class='info <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <div id='info-output' class='info-output'>
                                <script type='text/javascript'>
                                $.ajax({
                                        url: '/sys/inc/php/page/toolzinfo.php?tlz=<?php print $CODENAME; ?>',
                                        type: 'GET',
                                        success: function(result){
                                                $('#info-output').html(result);
                                        }
                                });
                                </script>
                        </div>
                </div>
        </div>
        <div class='pdr-toolz-footer-container'>
                <div class='left <?php print $transparency_second_sub_class; ?> fadein'>
                        <table><tr><td class='total'>TOTAL RUN : <?php print "<font class='$glow_color_class'>$totrun</font>"; ?></td></tr></table>
                </div>
                <div class='right <?php print $transparency_second_sub_class; ?> fadein'>
                        <table><tr><td class='text'><input class='toolz-run' id='action' type='submit' value='<?php echo $action ; ?>' name='submit'></td></tr></table>
                </div>
        </div>
</form>
<?php
if (isset($_POST['submit']))
{
        if ($_POST['submit']==="STOP")
        {
                file_put_contents($loadfile, "0");
                shell_exec("/usr/bin/php $UNITY_SCRIPT_DIR_PATH/unity-killer.php -c $CODENAME >/dev/null 2>&1 &");
        }
}
?>
