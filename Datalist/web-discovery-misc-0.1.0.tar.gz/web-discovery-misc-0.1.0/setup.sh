#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

DatalistDirPath="/var/lib/pandora/usr/datalists"
dbPath="/var/lib/pandora/db/user/datalist.db"

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="api-endpoints.txt"
desc="API Endpoints"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Common-DB-Backups.txt"
desc="Common DB backup files"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Passwords.txt"
desc="FuzzDB - Password file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Top1000-robotsdisallowed.txt"
desc="Top 1000 dissalowed for indexing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Top100-robotsdisallowed.txt"
desc="Top 100 dissalowed for indexing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Top500-robotsdisallowed.txt"
desc="Top 500 dissalowed for indexing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="wordpress-plugins.txt"
desc="Common Wordpress plugins PHP files"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="wordpress.txt"
desc="Common Wordpress PHP files"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi
