#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

DatalistDirPath="/var/lib/pandora/usr/datalists"
dbPath="/var/lib/pandora/db/user/datalist.db"

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="common_and_dutch.txt"
desc="Common web filename/dirname"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="common_and_french.txt"
desc="Common web filename/dirname"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="common_and_italian.txt"
desc="Common web filename/dirname"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="common_and_portugese.txt"
desc="Common web filename/dirname"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="common_and_spanish.txt"
desc="Common web filename/dirname"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Common_PHP_filenames.txt"
desc="Common PHP filenames"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="common.txt"
desc="Common web filename/dirname"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="dicc.txt"
desc="Common dir/file from dirsearch"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="KitchensinkDirectories.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-directories-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-directories.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-extensions-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-extensions.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-files-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-files.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-words-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-large-words.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-directories-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-directories.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-extensions-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-extensions.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-files-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-files.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-words-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-medium-words.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-directories-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-directories.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-extensions-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-extensions.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-files-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-files.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-words-lowercase.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="raft-small-words.txt"
desc="FuzzDB - Common directory name"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

