#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

DatalistDirPath="/var/lib/pandora/usr/datalists"
dbPath="/var/lib/pandora/db/user/datalist.db"

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="cfm.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="html.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="jsp.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="Logins.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="php.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="windows-asp.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="windows-aspx.txt"
desc="FuzzDB - Login file locations"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBCONTENT', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi
