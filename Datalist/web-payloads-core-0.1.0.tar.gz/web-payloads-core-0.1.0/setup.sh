#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

DatalistDirPath="/var/lib/pandora/usr/datalists"
dbPath="/var/lib/pandora/db/user/datalist.db"

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="SQLi-Auth-bypass.txt"
desc="SQLi - Auth Bypass"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="SQLi-Generic.txt"
desc="SQLi - Generic payloads"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="SQLi-Blind-Generic.txt"
desc="SQLi - Blind SQLi generic payloads"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="SQLi-Auth-bypass.txt"
desc="SQLi - Auth Bypass"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="SQLi-quick.txt"
desc="SQLi - Quick"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="LFI-Linux-checker.txt"
desc="LFI - Vulnerability check for Linux"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="LFI-Windows-checker.txt"
desc="LFI - Vulnerability check for Windows"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="LFI-Linux-discover.txt"
desc="FI - Path check for Linux"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="LFI-Windows-discover.txt"
desc="LFI - Path check for Windows"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="XXE-Fuzzing.txt"
desc="XXE - Fuzzing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="SSTI-expression.txt"
desc="SSTI - Expression for detection"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi


###########################################################################
#
###########################################################################

filename="JSON.Fuzzing.txt"
desc="JSON - Fuzzing"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('WEBPAYLOAD', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi


