#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

DatalistDirPath="/var/lib/pandora/datalists/default/"
dbPath="/var/lib/pandora/db/user/datalist.db"

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="alexaTop1mAXFRcommonSubdomains.txt"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains-top1mil-5000.txt"
desc="Ethicalhack3r&lsquo;s Zone Transfers The Alexa Top 1M"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi


###########################################################################
#
###########################################################################

filename="subdomains-top1mil-20000.txt"
desc="Ethicalhack3r&lsquo;s Zone Transfers The Alexa Top 1M"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains-top1mil-110000.txt"
desc="Ethicalhack3r&lsquo;s Zone Transfers The Alexa Top 1M"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains_bitquark_1000.txt"
desc="Bitquark DNSpop result"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains_bitquark_10000.txt"
desc="Bitquark DNSpop result"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains_bitquark_100000.txt"
desc="Bitquark DNSpop result"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$("awk 'END{print NR}' $DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"
		fi
	fi
fi





