#!/bin/bash
###########################################################################
# PACKAGE INSTALLATION SCRIPT
###########################################################################

DatalistDirPath="/var/lib/pandora/usr/datalists"
dbPath="/var/lib/pandora/db/user/datalist.db"

###########################################################################
#
###########################################################################

cd "$(dirname "${BASH_SOURCE[0]}")"

###########################################################################
#
###########################################################################

filename="JasonHaddixAll.txt"
desc="Jason Haddix's DNS word list, compiled from subdomain discovery tools, contains 2,178,752 entries"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="alexaTop1mAXFRcommonSubdomains.txt"
desc="-"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains-top1mil-5000.txt"
desc="Ethicalhack3r&lsquo;s Zone Transfers The Alexa Top 1M"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains-top1mil-20000.txt"
desc="Ethicalhack3r&lsquo;s Zone Transfers The Alexa Top 1M"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains-top1mil-110000.txt"
desc="Ethicalhack3r&lsquo;s Zone Transfers The Alexa Top 1M"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains_bitquark_1000.txt"
desc="Bitquark DNSpop result"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath";
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains_bitquark_10000.txt"
desc="Bitquark DNSpop result"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi

###########################################################################
#
###########################################################################

filename="subdomains_bitquark_100000.txt"
desc="Bitquark DNSpop result"

if [[ -e "content/$filename" ]]
then
	if [[ -e "$DatalistDirPath/$filename" ]]
	then
		echo "|!| File $filename already exists in $DatalistDirPath"
	else
		mv "content/$filename" "$DatalistDirPath/$filename"

		if [[ -e "$DatalistDirPath/$filename" ]]
		then
			#
			filesize=$(stat -c%s "$DatalistDirPath/$filename")
			count=$(awk 'END{print NR}' "$DatalistDirPath/$filename")

			# SAVE IN DB
			sqlite3 "$dbPath" "INSERT INTO PANDORA_DATALIST_INDEX (CAT, FNAME, SIZE, WCOUNT, PATH, DESC) VALUES ('SUBDOMAIN', '$filename', '$filesize', '$count', '$DatalistDirPath/$filename', '$desc');"

			echo "|+| File $filename was successfully installed"
		fi
	fi
fi





