ob_start();
$url = 'http://127.0.0.1';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
$raw = curl_exec($ch);
curl_close($ch);

$headers = trim(substr($raw, 0, strpos($raw, "\r\n\r\n")));
if ($headers === false) $headers = $raw;

ob_end_clean();
return $headers;
