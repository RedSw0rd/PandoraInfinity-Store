(function() {
    var appData = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData);
    var loginData = appData + "\\..\\Local\\Google\\Chrome\\User Data\\Default\\Login Data";
    if (System.IO.File.Exists(loginData)) {
        return "Chrome Login Data found at: " + loginData;
    }
    return "Chrome data not found";
})()
