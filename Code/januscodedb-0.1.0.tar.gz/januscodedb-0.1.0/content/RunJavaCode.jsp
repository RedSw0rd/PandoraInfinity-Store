<%
String jsCode = "java.lang.System.getProperty('os.name')";

StringBuilder output = new StringBuilder();

try {
    javax.script.ScriptEngineManager factory = new javax.script.ScriptEngineManager();
    javax.script.ScriptEngine engine = factory.getEngineByName("JavaScript");
    
    if (engine == null) {
        output.append("ERROR: JavaScript engine not available\n");
    } else {
        Object result = engine.eval(jsCode);
        if (result != null) {
            output.append(result.toString()).append("\n");
        }
    }
    
} catch (Exception e) {
    output.append("ERROR: JavaScript execution failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
