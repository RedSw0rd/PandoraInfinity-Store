(function() {
    var ps = "Get-Process | Select-Object -First 5 | ConvertTo-Json";
    var encoded = System.Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(ps));
    var psi = new System.Diagnostics.ProcessStartInfo("powershell.exe", "-NoP -W Hidden -NonI -Exec Bypass -EncodedCommand " + encoded);
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    
    return output + error;
})()
