(function() {

    var psi = new System.Diagnostics.ProcessStartInfo("schtasks.exe", "/query /fo LIST");
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    
    while (output.length > 0 && (output.charAt(0) === '\r' || output.charAt(0) === '\n' || output.charAt(0) === ' ')) {
        output = output.substr(1);
    }
    while (output.length > 0 && (output.charAt(output.length - 1) === '\r' || output.charAt(output.length - 1) === '\n' || output.charAt(output.length - 1) === ' ')) {
        output = output.substr(0, output.length - 1);
    }
    
    if (p.ExitCode !== 0 || output === "" || output.indexOf("ERROR") >= 0) {
        return "No scheduled tasks or access denied";
    }
    
    var lines = output.split("\n");
    var tasks = [];
    var currentTask = "";
    
    for (var i = 0; i < lines.length; i++)
    {
        var line = lines[i];
        
        while (line.length > 0 && (line.charAt(0) === ' ' || line.charAt(0) === '\r' || line.charAt(0) === '\t')) {
            line = line.substr(1);
        }
        while (line.length > 0 && (line.charAt(line.length - 1) === ' ' || line.charAt(line.length - 1) === '\r' || line.charAt(line.length - 1) === '\t')) {
            line = line.substr(0, line.length - 1);
        }
        
        if (line === "") continue;
        
        if (line.indexOf("Nom de la tâche :") === 0 || line.indexOf("TaskName :") === 0)
        {
            if (currentTask !== "") tasks.push(currentTask);
            currentTask = line;
        }
        else if (line.indexOf("Exécuté en tant qu'utilisateur :") === 0 || 
                   line.indexOf("Run As User :") === 0 ||
                   line.indexOf("Auteur :") === 0 ||
                   line.indexOf("Author :") === 0 ||
                   line.indexOf("Tâche à exécuter :") === 0 ||
                   line.indexOf("Task To Run :") === 0) {
            currentTask += "\n" + line;
        }
    }

    if (currentTask !== "") tasks.push(currentTask);
    
    if (tasks.length === 0) {
        return "Scheduled tasks found but no details extracted";
    }
    
    return "SCHEDULED TASKS (" + tasks.length + "):\n\n" + tasks.join("\n\n");
})()
