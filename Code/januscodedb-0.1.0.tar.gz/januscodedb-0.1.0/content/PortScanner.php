ob_start();
$ip = '127.0.0.1';
$ports = [21, 22, 23, 25, 53, 80, 443, 445, 3306, 3389];
foreach ($ports as $port) {
    $sock = @fsockopen($ip, $port, $errno, $errstr, 3);
    if ($sock) {
        fclose($sock);
        echo "TCP $port    \t: OPEN\n";
    } else {
        if (strpos($errstr, 'timed out') !== false || $errno == 110) {
            echo "TCP $port    \t: TIMEOUT\n";
        } else {
            echo "TCP $port    \t: CLOSED\n";
        }
    }
}
$output = ob_get_contents();
ob_end_clean();
return $output;
