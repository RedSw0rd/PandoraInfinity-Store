ob_start();

if (!class_exists('Memcached')) {
    ob_end_clean();
    return "ERROR: Memcached class not available";
}

$memcached_host = '127.0.0.1';
$memcached_port = 11211;
$timeout = 1; // sec

try {
    $m = new Memcached();
    $m->addServer($memcached_host, $memcached_port);
    $m->setOption(Memcached::OPT_CONNECT_TIMEOUT, $timeout * 1000);
    $m->setOption(Memcached::OPT_SEND_TIMEOUT, $timeout * 1000);
    $m->setOption(Memcached::OPT_RECV_TIMEOUT, $timeout * 1000);

    //
    $stats = $m->getStats();
    if (empty($stats) || !isset($stats["$memcached_host:$memcached_port"])) {
        ob_end_clean();
        return "ERROR: Failed to connect to Memcached ($memcached_host:$memcached_port)";
    }

    $server_key = "$memcached_host:$memcached_port";
    $output = "[+] Connected to Memcached at $memcached_host:$memcached_port\n";

    // Stats
    $output .= "[+] Stats:\n";
    foreach ($stats[$server_key] as $k => $v) {
        if (is_scalar($v)) {
            $output .= "$k: $v\n";
        }
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: Memcached execution failed - " . $e->getMessage();
}
