(function(host, user, pass, localFile, remoteFile) {
    // Vérifier que le fichier local existe
    if (!System.IO.File.Exists(localFile)) {
        return "ERROR: Local file not found: " + localFile;
    }
    
    // Choisir un répertoire temp existant (pas de création)
    var tempDir = null;
    var candidates = ["C:\\Windows\\Temp", "C:\\temp"];
    for (var i = 0; i < candidates.length; i++) {
        if (System.IO.Directory.Exists(candidates[i])) {
            tempDir = candidates[i];
            break;
        }
    }
    if (tempDir == null) {
        return "ERROR: No temp directory available";
    }
    
    // Générer un nom de script aléatoire
    var scriptName = System.Guid.NewGuid().ToString().substr(0, 8) + ".tmp";
    var scriptPath = System.IO.Path.Combine(tempDir, scriptName);
    
    // Créer le script FTP
    var ftp = "open " + host + "\n" + 
              user + "\n" + 
              pass + "\n" + 
              "binary\n" + 
              "put \"" + localFile + "\" \"" + remoteFile + "\"\n" + 
              "bye";
    System.IO.File.WriteAllText(scriptPath, ftp);
    
    // Exécuter ftp.exe
    var psi = new System.Diagnostics.ProcessStartInfo("ftp.exe", "-s:\"" + scriptPath + "\"");
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    psi.WorkingDirectory = tempDir;
    
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    
    // Nettoyer immédiatement
    try {
        System.IO.File.Delete(scriptPath);
    } catch (e) { }
    
    return "Exit code: " + p.ExitCode + "\nOutput:\n" + output + "\nError:\n" + error;
})("192.168.1.1", "user", "pass", "C:\\Windows\\Temp\\data.txt", "upload.txt")
