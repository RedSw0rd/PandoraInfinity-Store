<%
String filePath = "/WEB-INF/web.xml";

StringBuilder output = new StringBuilder();

try {
    java.io.InputStream is = application.getResourceAsStream(filePath);
    if (is == null) {
        java.io.File f = new java.io.File(filePath);
        if (f.exists() && f.canRead()) {
            is = new java.io.FileInputStream(f);
        } else {
            output.append("ERROR: File not found or not readable: ").append(filePath).append("\n");
        }
    }
    
    if (is != null) {
        byte[] buffer = new byte[8192];
        int n;
        while ((n = is.read(buffer)) != -1) {
            output.append(new String(buffer, 0, n, "UTF-8"));
        }
        is.close();
    }
    
} catch (Exception e) {
    output.append("ERROR: File read failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
