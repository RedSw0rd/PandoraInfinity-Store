ob_start();

$target = '127.0.0.1';
$ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 1433, 3306, 3389, 5432, 6379, 8080];
$timeout = 1;

try {
    $output = "[+] TCP Port Scanner\n";
    $output .= "[+] Target: $target\n";
    $output .= "[+] Ports: " . implode(', ', $ports) . "\n";
    $output .= "[+] Timeout: {$timeout}s per port\n\n";

    $open = [];
    $closed = 0;

    foreach ($ports as $port) {
        $output .= "Scanning $target:$port ... ";

        $old_error = error_reporting(0);
        $sock = @fsockopen($target, $port, $errno, $errstr, $timeout);
        error_reporting($old_error);

        if ($sock) {
            fclose($sock);
            $output .= "OPEN\n";
            $open[] = $port;
        } else {
            $output .= "closed\n";
            $closed++;
        }
    }

    $output .= "\n[+] Scan completed.\n";
    $output .= "[+] Open ports (" . count($open) . "): " . ($open ? implode(', ', $open) : 'none') . "\n";
    $output .= "[+] Closed/filtered: $closed\n";

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: Port scanner failed - " . $e->getMessage();
}
