(function() {
    var lines = [];
    lines.push('WScript.Echo "Hello from VBScript!"');
    lines.push('Set objFSO = CreateObject("Scripting.FileSystemObject")');
    lines.push('WScript.Echo "Temp folder: " & objFSO.GetSpecialFolder(2)');
    lines.push('WScript.Quit 0');
    
    var content = lines.join("\r\n");
    var tempFile = System.IO.Path.GetTempFileName().replace(/\.tmp$/, ".vbs");
    System.IO.File.WriteAllText(tempFile, content);
    
    var psi = new System.Diagnostics.ProcessStartInfo("cscript.exe", "//nologo \"" + tempFile + "\"");
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    
    System.IO.File.Delete(tempFile);
    return output + error;
})()
