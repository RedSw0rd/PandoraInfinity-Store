(function() {
    var result = "";
    
    // 1. Antivirus (via WMI)
    try {
        var wmi = GetObject("winmgmts:\\\\.\\root\\SecurityCenter2");
        var avs = wmi.ExecQuery("SELECT * FROM AntiVirusProduct");
        var enum = new Enumerator(avs);
        var avList = [];
        for (; !enum.atEnd(); enum.moveNext()) {
            var av = enum.item();
            avList.push(av.displayName + " (" + (av.productState & 0x1000 ? "Enabled" : "Disabled") + ")");
        }
        result += "Antivirus: " + (avList.length > 0 ? avList.join(", ") : "None detected") + "\n";
    } catch (e) {
        result += "Antivirus: Error (" + e.Message + ")\n";
    }
    
    // 2. Firewall (netsh)
    try {
        var psi = new System.Diagnostics.ProcessStartInfo("netsh.exe", "advfirewall show allprofiles state");
        psi.UseShellExecute = false;
        psi.RedirectStandardOutput = true;
        psi.RedirectStandardError = true;
        psi.CreateNoWindow = true;
        var p = System.Diagnostics.Process.Start(psi);
        var output = p.StandardOutput.ReadToEnd();
        p.WaitForExit();
        if (output.indexOf("ON") >= 0) {
            result += "Firewall: Active\n";
        } else {
            result += "Firewall: Inactive\n";
        }
    } catch (e) {
        result += "Firewall: Unknown\n";
    }
    
    // 3. UAC Level (registry)
    try {
        var rk = System.Reflection.Assembly.LoadWithPartialName("mscorlib").GetType("Microsoft.Win32.Registry").GetField("LocalMachine").GetValue(null);
        var subKey = rk.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
        if (subKey) {
            var uac = subKey.GetValue("EnableLUA");
            var consent = subKey.GetValue("ConsentPromptBehaviorAdmin");
            subKey.Close();
            var uacStatus = (uac == 1) ? "Enabled" : "Disabled";
            var consentLevel = "Unknown";
            if (consent == 0) consentLevel = "No prompt";
            else if (consent == 1) consentLevel = "Prompt for credentials";
            else if (consent == 2) consentLevel = "Prompt for consent";
            else if (consent == 5) consentLevel = "Prompt for consent (secure desktop)";
            result += "UAC: " + uacStatus + " (Level: " + consentLevel + ")\n";
        } else {
            result += "UAC: Registry access denied\n";
        }
    } catch (e) {
        result += "UAC: Error (" + e.Message + ")\n";
    }
    
    // 4. Windows Defender status
    try {
        var defenderKey = rk.OpenSubKey("SOFTWARE\\Microsoft\\Windows Defender");
        if (defenderKey) {
            var disabled = defenderKey.GetValue("DisableAntiSpyware");
            defenderKey.Close();
            result += "Windows Defender: " + (disabled == 1 ? "Disabled" : "Enabled") + "\n";
        }
    } catch (e) {
        // Silently skip if no access
    }
    
    return result;
})()
