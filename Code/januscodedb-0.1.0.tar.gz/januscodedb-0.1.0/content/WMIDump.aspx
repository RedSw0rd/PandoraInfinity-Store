(function() {
    var result = "";
    
    // Fonction utilitaire pour requêtes WMI
    function wmiQuery(namespace, query) {
        try {
            var wmi = GetObject("winmgmts:\\\\.\\\\" + namespace);
            var col = wmi.ExecQuery(query);
            var enum = new Enumerator(col);
            var items = [];
            for (; !enum.atEnd(); enum.moveNext()) {
                items.push(enum.item());
            }
            return items;
        } catch (e) {
            return null;
        }
    }
    
    // 
    var osItems = wmiQuery("root\\CIMV2", "SELECT Caption, Version, BuildNumber, OSArchitecture, RegisteredUser, Organization FROM Win32_OperatingSystem");
    if (osItems && osItems.length > 0) {
        var os = osItems[0];
        result += "=== SYSTEM ===\n";
        result += "OS: " + os.Caption + " " + os.Version + " (Build " + os.BuildNumber + ")\n";
        result += "Architecture: " + os.OSArchitecture + "\n";
        result += "Registered User: " + os.RegisteredUser + "\n";
        result += "Organization: " + os.Organization + "\n\n";
    }
    
    // 
    var compItems = wmiQuery("root\\CIMV2", "SELECT Name, Domain, Manufacturer, Model, NumberOfLogicalProcessors, TotalPhysicalMemory FROM Win32_ComputerSystem");
    if (compItems && compItems.length > 0) {
        var comp = compItems[0];
        result += "=== HARDWARE ===\n";
        result += "Hostname: " + comp.Name + "\n";
        result += "Domain: " + comp.Domain + "\n";
        result += "Manufacturer: " + comp.Manufacturer + "\n";
        result += "Model: " + comp.Model + "\n";
        result += "CPU Cores: " + comp.NumberOfLogicalProcessors + "\n";
        result += "RAM: " + Math.round(comp.TotalPhysicalMemory / 1048576) + " MB\n\n";
    }
    
    // 
    var diskItems = wmiQuery("root\\CIMV2", "SELECT DeviceID, Size, FreeSpace, FileSystem FROM Win32_LogicalDisk WHERE DriveType=3");
    if (diskItems && diskItems.length > 0) {
        result += "=== DISKS ===\n";
        for (var i = 0; i < diskItems.length; i++) {
            var disk = diskItems[i];
            var free = Math.round(disk.FreeSpace / 1073741824);
            var total = Math.round(disk.Size / 1073741824);
            result += disk.DeviceID + ": " + free + " GB free / " + total + " GB total (" + disk.FileSystem + ")\n";
        }
        result += "\n";
    }
    
    // 
    var nicItems = wmiQuery("root\\CIMV2", "SELECT Description, MACAddress, IPAddress, IPSubnet, DefaultIPGateway FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled=True");
    if (nicItems && nicItems.length > 0) {
        result += "=== NETWORK ===\n";
        for (var i = 0; i < nicItems.length; i++) {
            var nic = nicItems[i];
            var ip = nic.IPAddress ? nic.IPAddress.toArray().join(", ") : "N/A";
            var gateway = nic.DefaultIPGateway ? nic.DefaultIPGateway.toArray().join(", ") : "N/A";
            result += "Interface: " + nic.Description + "\n";
            result += "  MAC: " + nic.MACAddress + "\n";
            result += "  IP: " + ip + "\n";
            result += "  Gateway: " + gateway + "\n\n";
        }
    }
    
    // 
    var userItems = wmiQuery("root\\CIMV2", "SELECT Name, SID, Disabled, LocalAccount, FullName FROM Win32_UserAccount WHERE LocalAccount=True");
    if (userItems && userItems.length > 0) {
        result += "=== LOCAL USERS ===\n";
        for (var i = 0; i < userItems.length; i++) {
            var user = userItems[i];
            result += user.Name + " (SID: " + user.SID + ")" + (user.Disabled ? " [DISABLED]" : "") + "\n";
        }
        result += "\n";
    }
    
    // 
    var groupItems = wmiQuery("root\\CIMV2", "SELECT Name, SID FROM Win32_Group WHERE LocalAccount=True");
    if (groupItems && groupItems.length > 0) {
        result += "=== LOCAL GROUPS ===\n";
        for (var i = 0; i < groupItems.length; i++) {
            var group = groupItems[i];
            result += group.Name + " (SID: " + group.SID + ")\n";
        }
        result += "\n";
    }
    
    // 
    var procItems = wmiQuery("root\\CIMV2", "SELECT Name, ProcessId, ExecutablePath, CommandLine FROM Win32_Process");
    if (procItems && procItems.length > 0) {
        result += "=== PROCESSES (First 10) ===\n";
        for (var i = 0; i < Math.min(10, procItems.length); i++) {
            var proc = procItems[i];
            var cmd = proc.CommandLine ? proc.CommandLine : proc.ExecutablePath;
            result += proc.ProcessId + ": " + proc.Name + " -> " + (cmd || "N/A") + "\n";
        }
        result += "... (" + procItems.length + " total processes)\n\n";
    }
    
    // 
    var svcItems = wmiQuery("root\\CIMV2", "SELECT Name, DisplayName, State, StartMode, PathName FROM Win32_Service");
    if (svcItems && svcItems.length > 0) {
        result += "=== SERVICES (Running) ===\n";
        var runningCount = 0;
        for (var i = 0; i < svcItems.length && runningCount < 10; i++) {
            var svc = svcItems[i];
            if (svc.State === "Running") {
                result += svc.Name + " (" + svc.DisplayName + "): " + svc.PathName + "\n";
                runningCount++;
            }
        }
        result += "... (" + runningCount + " shown of " + svcItems.length + " total)\n\n";
    }
    
    // 
    var prodItems = wmiQuery("root\\CIMV2", "SELECT Name, Version FROM Win32_Product");
    if (prodItems && prodItems.length > 0) {
        result += "=== INSTALLED SOFTWARE (MSI) ===\n";
        for (var i = 0; i < Math.min(10, prodItems.length); i++) {
            var prod = prodItems[i];
            result += prod.Name + " (" + prod.Version + ")\n";
        }
        result += "... (" + prodItems.length + " total)\n\n";
    }
    
    // 
    var taskItems = wmiQuery("root\\CIMV2", "SELECT Name, Command, RunAsUser FROM Win32_ScheduledJob");
    if (taskItems && taskItems.length > 0) {
        result += "=== SCHEDULED JOBS ===\n";
        for (var i = 0; i < taskItems.length; i++) {
            var task = taskItems[i];
            result += task.Name + " -> " + task.Command + " (User: " + task.RunAsUser + ")\n";
        }
        result += "\n";
    }
    
    // 
    var shareItems = wmiQuery("root\\CIMV2", "SELECT Name, Path, Description FROM Win32_Share");
    if (shareItems && shareItems.length > 0) {
        result += "=== NETWORK SHARES ===\n";
        for (var i = 0; i < shareItems.length; i++) {
            var share = shareItems[i];
            result += share.Name + " -> " + share.Path + " (" + (share.Description || "No description") + ")\n";
        }
        result += "\n";
    }
    
    //
    var secItems = wmiQuery("root\\SecurityCenter2", "SELECT displayName, productState FROM AntiVirusProduct");
    if (secItems && secItems.length > 0) {
        result += "=== SECURITY PRODUCTS ===\n";
        for (var i = 0; i < secItems.length; i++) {
            var av = secItems[i];
            var status = (av.productState & 0x1000) ? "Enabled" : "Disabled";
            result += "AV: " + av.displayName + " (" + status + ")\n";
        }
    }
    
    return result || "WMI query returned no data";
})()
