(function() {
    var lines = [];
    lines.push("@echo off");
    lines.push("echo Hello from batch!");
    lines.push("ipconfig /all");
    lines.push("echo Done.");
    
    var content = lines.join("\r\n");
    var tempFile = System.IO.Path.GetTempFileName().replace(/\.tmp$/, ".bat");
    System.IO.File.WriteAllText(tempFile, content);
    
    var psi = new System.Diagnostics.ProcessStartInfo("cmd.exe", "/c \"" + tempFile + "\"");
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    
    System.IO.File.Delete(tempFile);
    return output + error;
})()
