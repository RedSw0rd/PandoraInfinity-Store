(function() {
    var env = System.Environment.GetEnvironmentVariables();
    var sensitive = [
        "USERNAME", "USERDOMAIN", "COMPUTERNAME", "USERPROFILE",
        "APPDATA", "LOCALAPPDATA", "HOMEPATH", "TEMP", "TMP",
        "OS", "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER",
        "PATH", "WINDIR", "SYSTEMROOT", "PROGRAMFILES", "PROGRAMFILES(X86)",
        "COMMONPROGRAMFILES", "COMMONPROGRAMFILES(X86)",
        "ALLUSERSPROFILE", "PUBLIC", "LOGONSERVER",
        "SESSIONNAME", "CLIENTNAME", "PATHEXT"
    ];
    var result = "";
    for (var i = 0; i < sensitive.length; i++) {
        var val = env.Item(sensitive[i]);
        if (val) result += sensitive[i] + "=" + val + "\n";
    }
    return result || "No environment variables found";
})()
