ob_start();

if (!class_exists('Redis')) {
    ob_end_clean();
    return "ERROR: Redis class not available";
}

// CONFIG
$redis_host = '127.0.0.1';
$redis_port = 6379;
$redis_timeout = 1; // secondes

try {
    $redis = new Redis();
    
    if (!$redis->connect($redis_host, $redis_port, $redis_timeout)) {
        ob_end_clean();
        return "ERROR: Failed to connect to Redis ($redis_host:$redis_port)";
    }

    // AUTH
    // $redis->auth('PASSWORD');

    $info = $redis->info();
    $keys = $redis->keys('*');
    $dbsize = $redis->dbSize();

    $output = "[+] Connected to Redis at $redis_host:$redis_port\n";
    $output .= "[+] DB Size: $dbsize keys\n";

    if (is_array($info)) {
        $output .= "[+] Redis Info:\n";
        foreach ($info as $k => $v) {
            if (!is_string($v)) continue;
            $output .= "$k: $v\n";
        }
    }

    $output .= "\n[+] Keys (first 100):\n";
    $keyList = array_slice($keys, 0, 100);
    $output .= implode("\n", $keyList);
    if (count($keys) > 100) {
        $output .= "\n... (+ " . (count($keys) - 100) . " more keys)";
    }

    $redis->close();
    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: Redis execution failed - " . $e->getMessage();
}
