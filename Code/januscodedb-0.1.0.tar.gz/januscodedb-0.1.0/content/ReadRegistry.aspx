(function(key, value) {
    try {
        var rk = new System.Object();
        rk = System.Reflection.Assembly.LoadWithPartialName("mscorlib").GetType("Microsoft.Win32.Registry").GetField("LocalMachine").GetValue(null);
        var subKey = rk.OpenSubKey(key);
        if (subKey) {
            var val = subKey.GetValue(value);
            subKey.Close();
            return val ? val.toString() : "Value is null";
        }
        return "Key not found";
    } catch (e) {
        return "Error: " + e.Message;
    }
})("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", "ProductName")
